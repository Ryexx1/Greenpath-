<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Booking</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" media="screen" href="catalogStyle.php">
    
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <!-- Link to the Font Awesome CSS -->
    <script src="https://kit.fontawesome.com/67cac72898.js" crossorigin="anonymous"></script>


</head>  
<body>
    <!-- Navbar-->
    <div class="header">
    <div class="container1">
        <div class="logo-nav-container">
            <div class="navbar">
                <nav>  
                    <ul id="MenuItems" class="center-menu">
                        <li class="pages"><a href="guidelines.php" style="color: white">Guidelines</a></li>
                        <li class="pages"><a href="catalog.php" style="border-bottom: 2px solid white; color: white">Booking</a></li>
                        <li class="pages"><a href="repair.php" style="color: white">Maintenance</a></li>
                        <li class="logo-item"><a href="index.php"><img src="images/ima/1/r1.png" alt="Logo"></a></li> 
                        <li class="pages"><a href="trans.php" style="color: white">Transaction</a></li>
                        <li class="pages"><a href="about.php" style="color: white">About Us</a></li>
                        <li class="pages"><a href="signin.php" style="color: white">Log In</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>
<!-- navbar endd -->



<div class="container cards-container">
    <div class="booking-paragraph">
        <p>
            Welcome to our booking page, where the journey begins! At GreenPath Rental, we're thrilled to offer you an exciting array of bikes for your adventures. Whether you're craving the thrill of mountain trails, the practicality of a mom's bike, or the joy of tandem rides, we have the perfect ride for you.
            Booking with us is a breeze! Simply explore our bike options, each crafted for comfort and performance. Once you've found your ideal companion for the road, click on the "Book Now" button, and let the journey unfold.
            Our booking process is designed with your convenience in mind. Choose your preferred date, time, and duration, and voilà – you're on your way to enjoying the freedom of two wheels. If you have any questions or need assistance, our friendly team is just a message or call away.
            Get ready to pedal into new adventures with GreenPath Rental. We can't wait to be part of your biking experience!
        </p>
    </div>
</div>



<div class="container cards-container">
    <div class="row cards-row">
        <div class="col-xl-4 col-sm-4 col-4">
            <div class="card">
                <div class="card-content">
                    <div class="card-body">
                        <div class="media d-flex">
                            <div class="media-body text-left">
                                        <h1>Mountain Bike</h1>
                                        <p i="pedal">Sturdy frames, rugged tires, and versatile 
                                        gears—your ultimate campus exploration companion.</p>
                                      <div class="link-btn">  <a href="bookMtn.php" class="btn text-center"> Book Now <i class="fas fa-long-arrow-alt-right"></i> </a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      
        <div class="col-xl-4 col-sm-6 col-12">
            <div class="card">
                <div class="card-content">
                    <div class="card-body">
                        <div class="media d-flex">
                            <div class="media-body text-left">
                                        <h1>Mom's Bike</h1>
                                        <p i="pedal">Keep your campus life organized and
                                        clutter-free with a basket bike.</p>
                                        <div class="link-btn">  <a href="bookMom.php" class="btn text-center"> Book Now <i class="fas fa-long-arrow-alt-right"></i> </a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      
        <div class="col-xl-4 col-sm-6 col-12">
            <div class="card">
                <div class="card-content">
                    <div class="card-body">
                        <div class="media d-flex">
                            <div class="media-body text-left">
                                        <h1>Tandem Bike</h1>
                                        <p i="pedal">No more waiting for your friends—you'll always 
                                        arrive at your campus destination together.</p>
                                        <div class="link-btn">  <a href="bookTd.php" class="btn text-center"> Book Now <i class="fas fa-long-arrow-alt-right"></i> </a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div><!-- row end -->
</div><!-- container end -->



<!-- New section for larger videos -->
<div class="video-section">
    <div class="containervid">
        <div class="video1">
            <video controls width="640" height="360" poster="images/ima/3/book.png">
                <source src="images/ima/3/booking.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>
        <div class="video2">
            <video controls width="640" height="360" poster="images/ima/3/return.png">
                <source src="images/ima/3/return.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>
    </div>
</div>





<!--- Footer Section -->
<div class="footer">
    <div class="footer-container">
        <div class="footer-row">

        <!-- Column 1 -->
        <div class="footer-col-1">
            <h3 class="footer-h3">Follow Us</h3>
            <ul class="footer-ul">
                <a href="https://www.facebook.com/profile.php?id=61552094544554&mibextid=ZbWKwL">
                    <li>
                        <img class="social-icon" src="images/ima/1/facebook.png" alt="Facebook">
                    </li>
                </a>
                <a href="https://instagram.com/greenpath_rental?igshid=MzMyNGUyNmU2YQ==">
                    <li>
                        <img class="social-icon" src="images/ima/1/insta.png" alt="Instagram">
                    </li>
                </a>
            </ul>
        </div>

        <!-- Column 2 -->
        <div class="footer-col-2">
            <img src="images/ima/1/r1.png">
            <p class="footer-p">Paving Paths for Brighter Futures</p>
        </div>

        <!-- Column 3 -->
        <div class="footer-col-3">
            <h3 class="footer-h3">Contact Us</h3>
            <p class="footer-p" style="font-weight: lighter;">greenpath@gmail.com</p><br>
            <p class="footer-p" style="font-weight: lighter;">(+63) 968-459-3721</p>
        </div>
        </div>
        <hr class="footer-hr">
        <p class="Copyright" style="font-weight: bold;">Copyright 2022</p>
    </div>
</div>

</body>    
</html>
