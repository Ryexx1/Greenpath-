<?php header("Content-type: text/css"); ?>
/* Reset styles for all elements */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Trebuchet MS, sans-serif;

}


/* NAVBAR */
/* Styles for the logo image */
.logo-item img {
    width: 90px;
    height: auto;
    margin-left: 150px;
    margin-right: 150px;
}

/* Center the navigation menu items */
.center-menu {
    list-style-type: none;
    display: flex;
    justify-content: center;
    align-items: center;
}

.pages {
    margin-right: 25px; 
    margin-left: 25px; 
    font-size: 16px;
    font-family: Trebuchet MS, sans-serif;
}

.pages:hover{
    background: rgba(255, 255, 255, 0.2);
    padding: 15px 0 15px 0;
}

/* Styles for anchor links */
a {
    text-decoration: none;
    color: #000000;
    font-family: Trebuchet MS, sans-serif;
    color: white;
    padding: 0 5px 0 5px;
}

.container {
    max-width: 1300px;
    margin: auto;

}

.header{
    background-color: #062644;
    margin-bottom: 20px;
}
.settingsContent{
    align-items: center;
    justify-content: center;
}






/* C1 */
.modal-body, .modal-content{
    border-radius: 0px; 
    color: #fff;
}
.modal-content{
    background-color: #062644;
}
.modal-header{
    background-color: #062644;
    color: #fff;
}
.custom-btn{
    color: #fff;
    background-color:#062644;
    padding: 5px 10px 5px 10px;
}
.custom-btn:hover{
    colo: #fff;
}
.modal-title{
    font-size: 15px;
}
.modal-body{
    background-color:#fff;
    color: #062644;
}
.modal-body h6{
    text-align: center;
    margin: 10px;
}

.form{
    text-align: center;
    align-items: center; 
    justify-content: center;
}
#credentialsForm input{ 
    font-family: Trebuchet MS, sans-serif;
    outline: 1;
    width: 90%; 
    border: 2px solid #ccc; 
    margin: 20px; 
    padding: 15px; 
    box-sizing: border-box; 
    font-size: 14px; 
    border-radius: 0px;
    } 
.mb-3{
    text-align: center; 
    justify-content: center; 
    align-items: center;
}
#btn{
    color: #fff; 
    background-color: #F18A06;
    border: 2px solid #ccc;
    border-radius: 0px; 
    margin: 20px;
    margin-top: 0px; 
    padding: 10px; 
    width: 91%;
    font-weight: bold;
    justify-content: center;
} 


/**c2 */
#historyHeading{
    text-align: center;
    margin: 10px;
}

.card-header{
    font-weight: bold;
    font-size: 20px;
    color: #fff;
    background-color:#062644;
}
.card-text{
    text-align: left; 
    margin: 0; 
    padding: 0;
    font-size: 20px;
}
.cancel{
    padding: 5px 10px 5px 10px; 
    text-align: right; 
    background-color: #062644; 
    color: #fff; 
    font-weight: bold;
    border-radius: 0px;
    margin-top: 10px;
    align-item: right;
    float: right;
}
.cancel:hover{
    background-color: #F18A06;
    color: #fff;
}

.noData{
    text-align: center; 
}
.noDate img{
    margin: 25%;
}


/* Footer styles */
/* Styling for the footer container */
.footer {
    background: #062644;
    color: white;
    font-size: 16px;
    text-align: center;
    padding: 40px 0;
    margin-top: 50px;
}

/* Styling for paragraphs within the footer */
.footer-p {
    color: white;
    font-weight: bold;
}

/* Styling for footer heading */
.footer-h3 {
    color: white;
    padding-top: 30px;
    margin-bottom: 20px;
    font-size: 20px;
    font-weight: bold;
}

/* Styling for the footer container */
.footer-container {
    margin: auto;
    max-width: 1000px;
    padding-left: 5px;
    padding-right: 5px;
}

/* Styling for the row in the footer */
.footer-row {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: space-around;
}

/* Styling for the first column in the footer */
.footer-col-1 {
    min-height: 200px;
    margin-bottom: 20px;
    font-family: Trebuchet MS, sans-serif;
    flex-basis: 12%;
    text-align: center;
}

/* Styling for social media icons */
.social-icon {
    width: 90px;
    height: 90px;
}

/* Styling for the second column in the footer */
.footer-col-2 {
    padding-left: 5px;
    min-height: 200px;
    margin-bottom: 20px;
    flex: 1;
    font-family: Trebuchet MS, sans-serif;
    text-align: center;
}

/* Styling for images in the second column of the footer */
.footer-col-2 img {
    width: 180px;
    margin-bottom: 20px;
}

/* Styling for the third column in the footer */
.footer-col-3 {
    min-height: 200px;
    margin-bottom: 10px;
    font-family: Trebuchet MS, sans-serif;
    flex-basis: 12%;
    text-align: center;
}

/* Styling for the footer unordered list */
.footer-ul {
    list-style-type: none;
    display: flex;
    list-style: none;
    padding: 0;
}

/* Styling for list items in the footer unordered list */
.footer-ul li {
    margin-right: 1px;
}

/* Styling for the horizontal rule in the footer */
.footer-hr {
    border: none;
    background: #b5b5b5;
    height: 1px;
    margin: 20px 0;
}

/* Styling for the copyright text in the footer */
.Copyright {
    font-size: 12px;
    text-align: center;
    font-family: Trebuchet MS, sans-serif;
}
