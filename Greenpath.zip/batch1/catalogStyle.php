<?php header("Content-type: text/css"); ?>
/* Reset styles for all elements */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Trebuchet MS, sans-serif;

}


/* NAVBAR */
/* Styles for the logo image */
.logo-item img {
    width: 90px;
    height: auto;
    margin-left: 150px;
    margin-right: 150px;
}

/* Center the navigation menu items */
.center-menu {
    list-style-type: none;
    display: flex;
    justify-content: center;
    align-items: center;
}

.center-menu:hover {
    color: white;
}

.pages {
    margin-right: 25px; 
    margin-left: 25px; 
    font-size: 16px;
    font-family: Trebuchet MS, sans-serif;
}

.pages:hover{
    background: rgba(255, 255, 255, 0.2);
    padding: 15px 0 15px 0;
}

/* Styles for anchor links */
a {
    text-decoration: none;
    font-family: Trebuchet MS, sans-serif;
    color: white;
    padding: 0 5px 0 5px;
}

a:hover {
    text-decoration: none;
}

.container1 {
    max-width: 1300px;
    margin: auto;
    height: 95px;
}

.header{
    background-color: #062644;
    margin-bottom: 50px;
}

.container {
    max-width: 1300px;
    margin: auto;
}


/* C1, C2, C3 */
.booking-paragraph {
    font-size: 16px;
    line-height: 1.8;
    text-align: center;
    max-width: 1000px;
    margin: 0 auto;
    padding-bottom: 30px;
    color: black;
    font-family: Trebuchet MS, sans-serif;
}


.card-content{
    text-align: right;
}

.text-and-button p {
    font-size: 16px;
    color: white;
    margin: 0 0 10px 150px;
    font-family: Trebuchet MS, sans-serif;
}

.btn {
    height: 50px;
    display: inline-block;
    padding: 10px 20px;
    color: white;
    background-color: #f18a06;
    text-decoration: none;
    border: 3px solid white;
    border-radius: 30px;
    font-weight: bold;
    margin: auto;
    box-shadow: 0px 10px 15px rgba(0, 0, 0, 0.2);
    text-align: center;
}
.media-body h1{
    
    text-align: center;
}

.btn .fas.fa-long-arrow-alt-right {
    font-size: 14px;
    margin: 5px 10px;
}


.btn:hover{
    background-color: #f59d37;
    color: white;
}

.link-btn{
    text-align: center;}



/* C4 */
.video-section {
    padding: 60px 0;
}

.containervid {
    display: flex;
}

.video1 {
    width: 50%;
    text-align: center;
    box-sizing: border-box;
    padding: 0 0 0 60px;
}

.video2 {
    width: 50%;
    text-align: center;
    box-sizing: border-box;
    padding: 0 60px 0 0;
}

video {
    max-width: 100%; /* Make the video responsive within its container */
    width: 80%; /* Expand the video to the full width of its container */
    height: auto; /* Maintain the video's aspect ratio */
}

    /* Footer styles */
/* Styling for the footer container */
.footer {
    background: #062644;
    color: white;
    font-size: 16px;
    text-align: center;
    padding: 21px 0;
    margin-top: 50px;
}

/* Styling for paragraphs within the footer */
.footer-p {
    color: white;
    font-weight: bold;
}

/* Styling for footer heading */
.footer-h3 {
    color: white;
    padding-top: 40px;
    margin-bottom: 20px;
    font-size: 20px;
    font-weight: bold;
}

/* Styling for the footer container */
.footer-container {
    margin: auto;
    max-width: 1000px;
    padding-left: 5px;
    padding-right: 5px;
}

/* Styling for the row in the footer */
.footer-row {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: space-around;
}

/* Styling for the first column in the footer */
.footer-col-1 {
    min-height: 200px;
    margin-bottom: 20px;
    font-family: Trebuchet MS, sans-serif;
    flex-basis: 12%;
    text-align: center;
}

/* Styling for social media icons */
.social-icon {
    width: 90px;
    height: 90px;
}

/* Styling for the second column in the footer */
.footer-col-2 {
    padding-left: 5px;
    min-height: 200px;
    margin-bottom: 20px;
    flex: 1;
    font-family: Trebuchet MS, sans-serif;
    text-align: center;
}

/* Styling for images in the second column of the footer */
.footer-col-2 img {
    width: 180px;
    margin-bottom: 20px;
}

/* Styling for the third column in the footer */
.footer-col-3 {
    min-height: 200px;
    margin-bottom: 10px;
    font-family: Trebuchet MS, sans-serif;
    flex-basis: 12%;
    text-align: center;
}

/* Styling for the footer unordered list */
.footer-ul {
    list-style-type: none;
    display: flex;
    list-style: none;
    padding: 0;
}

/* Styling for list items in the footer unordered list */
.footer-ul li {
    margin-right: 1px;
}

/* Styling for the horizontal rule in the footer */
.footer-hr {
    border: none;
    background: #b5b5b5;
    height: 1px;
    margin: 20px 0;
}

/* Styling for the copyright text in the footer */
.Copyright {
    font-size: 12px;
    text-align: center;
    font-family: Trebuchet MS, sans-serif;
}