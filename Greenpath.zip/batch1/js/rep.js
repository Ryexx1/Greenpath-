function updatePlace(value, inputId) {
    document.getElementById(inputId).value = value;
}
$(document).ready(function () {
// Handle dropdown item click
$('.dropdown-menu').on('click', '.dropdown-item', function () {
var selectedOption = $(this).text();
var dropdownButton = $(this).closest('.single-column').find('.dropdown-toggle');
dropdownButton.text(selectedOption).css('color', 'black');
});

// Handle form submission
$('#submitButton').on('click', function (e) {
var locationDropdown = $('#locationDropDown');
var priorityDropdown = $('#priorityDropDown');
var typeOfRepDropdown = $('#typeOfRepDropDown');
var isValid = true;

// Check for Location dropdown
if (locationDropdown.text().trim() === 'Location') {
isValid = false;
document.getElementById("error-msg").innerHTML = "Please select an option for Location";
}

// Check for Priority Level dropdown
if (priorityDropdown.text().trim() === 'Priority Level') {
isValid = false;

document.getElementById("error-msg").innerHTML = "Please select an option for Priority Level";
}
if (typeOfRepDropdown.text().trim() === 'Type of Repair') {
isValid = false;

document.getElementById("error-msg").innerHTML = "Please select an option for Type of Repair";
}
// Prevent form submission if validation fails
if (!isValid) {
e.preventDefault();
}
});
});