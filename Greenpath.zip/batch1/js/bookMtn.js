document.addEventListener('click', function (event) {
    var pickBtn = event.target.closest('.pickBtn');

    if (pickBtn) {
        // Remove the lifted and active classes from other buttons and cards
        $(".pickBtn").not(pickBtn).removeClass("active");
        $(".card").removeClass("lifted");

        // Toggle the active class on the picked button
        pickBtn.classList.toggle('active');

        // Get the bike number from the data attribute
        let bikeNumber = pickBtn.getAttribute("data-bike-number");

        // Set the bike number in the readonly input's placeholder
        $("#bikeNumberInput").attr("placeholder", "Selected Bike: " + bikeNumber);

        // Set the bike number as the value of the readonly input
        $("#bikeNumberInput").val(bikeNumber);
       // Set the color of the input text
        $("#bikeNumberInput").css("color", "#B0B0B0");
    }
});

$(document).ready(function () {
    // Initialize date picker
    $('#postDate').daterangepicker({
        singleDatePicker: true,
        autoApply: true,
        minDate: moment(),
        showDropdowns: false,
        isInvalidDate: function (date) {
            // Disable selection of Sundays
            return date.day() === 0; // 0 represents Sunday
        },
        locale: {
            format: 'MMM D', // Customize the date format
            separator: ' to ',
        },
        showRangeLabelOnSingleDatePicker: false,
        ranges: {
            'Today': [moment()],
            'Tomorrow': [moment().add(1, 'days')],
            // Add more ranges as needed
        },
    });

    // Set the initial placeholder value with grey color
    $('#postDate').val("Pick a Date").css('color', 'grey');
    
    // Event handler for applying date range
    $('#postDate').on('apply.daterangepicker', function (ev, picker) {
        checkWeekend();

        // Update the displayed text if only one day is selected
        if (picker.endDate.diff(picker.startDate, 'days') === 0) {
            $('#postDate').val(picker.startDate.format('MMM D')).css('color', 'black');
        }
    });
});


function checkWeekend() {
    // Get the selected date from the input
    var selectedDate = new Date(document.getElementById("postDate").value);

    // Check if the selected date is a Saturday (6) or Sunday (0)
    if (selectedDate.getDay() === 0) {
        // Show an error message
        document.getElementById("error-msg").innerText = " GreenPath Cycles is not open on Sundays";
        // Clear the selected date
        document.getElementById("postDate").value = "";
    } else {
        // Clear the error message
        document.getElementById("error-msg").innerText = "";
    }
}

function onSubmitButtonClick() {
    // Check for the weekend again before submitting
    if (!checkWeekend()) {
        return;
    }

    let studentNumber = $("#studNum").val();
    let date = $("#postDate").val();
    let bikeNumber = $("#bikeNumberInput").val();
    let paymentDropdown = $('#PaymentInputValue'); // Use the hidden input to get the selected value

    // Check if a valid payment option is selected
    if (paymentDropdown.val() === "") {
        // Display error message
        document.getElementById("error-msg").innerHTML = "Please choose a payment option";
        return; // Stop the function execution if there's an error
    }

    console.log("Student Number: " + studentNumber);
    console.log("Date: " + date);
    console.log("Bike Number: " + bikeNumber);
    console.log("Payment Option: " + Payment.val());
    // Submit the form
    $("form").submit();
}

function dropdownSelect() {
    // Simulate a click on the dropdown button to open it
    $('#PaymentDropDown').dropdown('toggle');
}

function updatePlaceValue(value, inputId) {
    var inputElement = document.getElementById(inputId);

    // Check if the element exists before setting its value
    if (inputElement) {
        inputElement.value = value;
    } else {
        console.error("Element with ID " + inputId + " not found.");
    }
}

$(document).ready(function () {
    // Dropdown click event
    $('.dropdown-menu').on('click', '.dropdown-item', function () {
        var dropdownButton = $(this).closest('.single-column').find('.btn.dropdown-toggle');
        var selectedOption = $(this).text();  // Retrieve the text of the clicked item

        // Update the button text with the selected option
        dropdownButton.text(selectedOption).css('color', 'black');

        // Call the updatePlace function to set the hidden input value
        var inputId = dropdownButton.attr('id').replace('DropDown', 'InputValue');
        updatePlaceValue(selectedOption, inputId);
    });
});
