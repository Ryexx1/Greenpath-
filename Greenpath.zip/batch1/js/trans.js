$(document).ready(function () {
    // Trigger the modal to show upon page load
    $('#credentialsModal').modal({
        backdrop: 'static',
    });

    // Function to handle cancellation of repair
    function cancelRepair(form) {
        // Display a confirmation alert
        if (confirm('Are you sure you want to cancel this repair request?')) {
            // User clicked OK, proceed with cancellation
            alert('Repair Request Has Been Canceled');
            // Now, submit the cancellation form
            submitCancellationForm(form);
        }
    }

    // Function to handle cancellation of booking
    function cancelBook(form) {
        // Display a confirmation alert
        if (confirm('Are you sure you want to cancel this booking?')) {
            // User clicked OK, proceed with cancellation
            alert('Booking Has Been Canceled');
            // Now, submit the cancellation form
            updateCard(form)
            submitCancellationForm(form);
        }
    }

    // Handle form submissions
    $('.cancel-form').submit(function (event) {
        event.preventDefault();
        var form = $(this);
        // Display a confirmation alert
        if (confirm('Are you sure you want to cancel this transaction?')) {
            // User clicked OK, proceed with cancellation
            updateCard(form)
            submitCancellationForm(form);
        }
    });

    // Function to submit the cancellation form via AJAX
    function submitCancellationForm(form) {
        // Display a confirmation alert before proceeding
        if (confirm('Are you sure you want to proceed with the cancellation?')) {
            var formData = form.serialize();
            $.ajax({
                type: 'POST',
                url: '',
                data: formData,
                success: function (response) {
                    // Handle the response from the server (e.g., update UI)
                    var result = JSON.parse(response);
                    if (result.status === 'success') {
                        showAlert('success', result.message);
                        // Modify the corresponding card in the UI
                        updateCard(form);
                    } else {
                        showAlert('danger', result.message);
                    }
                },
                error: function (error) {
                    console.error('Error:', error);
                }
            });
        }
    }

    // Function to modify the card in the UI to indicate cancellation
    function updateCard(form) {
        var card = form.closest('.card');
        var bookingNo = form.find('input[name="BookingNo"]').val();

        // Update the card content or styling to indicate cancellation
        card.find('.card-header').text('Canceled - ' + card.find('.card-header').text());
        card.find('.card-body').html('<p class="card-text">This transaction has been canceled.</p>');

        // Change the text of the cancel button to "CANCELED"
        form.find('button').text('CANCELED').prop('disabled', true);

        // Optionally, you can remove the cancel button or update its functionality
        // form.remove();

        // You can also update the card styling to indicate cancellation
        card.addClass('canceled-card');
    }

});
