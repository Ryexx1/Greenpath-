<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Mom's Bike</title>
    <link rel="stylesheet" type="text/css" media="screen" href="bike.php">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

  <!-- Link to the Font Awesome CSS -->
  <script src="https://kit.fontawesome.com/67cac72898.js" crossorigin="anonymous"></script>
</head>  
<body>





<!-- Navbar-->
<div class="header">
    <div class="container">
        <div class="logo-nav-container">
            <div class="navbar">
                <nav>  
                    <ul id="MenuItems" class="center-menu">
                        <li class="pages"><a href="guidelines.php" style="border-bottom: 2px solid white">Guidelines</a></li>
                        <li class="pages"><a href="catalog.php">Booking</a></li>
                        <li class="pages"><a href="repair.php">Maintenance</a></li>
                        <li class="logo-item"><a href="index.php"><img src="images/ima/1/r1.png" alt="Logo"></a></li>
                        <li class="pages"><a href="trans.php">Transaction</a></li>
                        <li class="pages"><a href="about.php">About Us</a></li>
                        <li class="pages"><a href="signin.php">Log In</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>



<!-- distinction (C1) -->
<div class="paragraph-section">
    <div class="container">
        <h1> A Smart Solution: Your Key to Effortless Mobility</h1>
        <p class="paragraph-text">
        Mom's Bike, a charming companion for campus exploration, features a spacious 
        front basket that transforms daily commuting into a hassle-free experience. 
        Designed with practicality in mind, this unique bicycle offers students a convenient 
        solution for carrying books, essentials, and personal belongings effortlessly. 
        With its distinctive front-mounted basket, Mom's Bike aligns seamlessly with the Dutch 
        cycling culture, providing a touch of European charm to campus life. Say goodbye to heavy 
        backpacks and hello to stress-free navigation as you glide through your academic journey 
        with the ease and efficiency of Mom's Bike. Embrace sustainable and stylish campus mobility 
        with this eco-friendly ride that combines functionality with a touch of timeless elegance.
        </p>
    </div>
</div>

    <div class="content-container">
        <!-- Left Column with "mbike" -->
        <div class="left-column">
            <img id="mbike" src="images/ima/3/ibike.png" alt="Your Image">
        </div>

        <!-- 2x2 grid 1 (C2) -->
        <div class="right-column">
            <!-- Row 1, Column 1 -->
            <div class="heading-box">
                <h2 class="highlighted-heading">Safety Guidelines</h2>
                    <div class="description-container">
                        <span class="description-text">Inspect the Bike and Basket</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box"> Before riding a mom's bike, thoroughly inspect both the bike and the basket. Ensure that the bike's frame, wheels, brakes, and gears are in good condition. Also, check the stability of the basket to prevent any unexpected issues during your ride. <br> <a href="index.php" style= "color: white; text-decoration: underline;">Here's how to:</a></div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Adjust the Seat Height</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box"> Make sure the bike's seat is adjusted to a comfortable and safe height. Proper seat adjustment helps maintain balance and control while riding, reducing the risk of accidents. <br> <a href="index.php" style= "color: white; text-decoration: underline;">Here's how to:</a></div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Check Your Brakes</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box"> Squeeze both brake levers to ensure they function smoothly. If the brakes are not working correctly, report the issue to the rental service and do not ride the bike until the brakes are fixed. <br> <a href="index.php" style= "color: white; text-decoration: underline;">Here's how to:</a></div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Secure Your Belongings</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box"> If you use the bike's basket to carry items, ensure that they are securely fastened. Avoid overloading the basket with heavy objects, as this can affect the bike's stability. Secure your belongings to prevent them from falling during the ride. <br> <a href="index.php" style= "color: white; text-decoration: underline;">Here's how to:</a></div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Be Cautious on Turns and Curves</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box"> When navigating turns or curves on campus paths, reduce your speed and approach them with caution. The added weight from the basket can impact your bike's balance. Slow down, lean into the turns, and maintain a firm grip on the handlebars to prevent tipping. <br> <a href="index.php" style= "color: white; text-decoration: underline;">Here's how to:</a></div>
                    </div>
                        <div class="separating-line"></div>
            </div>
        
        <!-- 2x2 grid 2 (C3) -->
            <!-- Row 1, Column 2 -->
            <div class="heading-box">
                <h2 class="highlighted-heading">User Responsibility</h2>
                    <div class="description-container">
                        <span class="description-text">Bike Inspection</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box">Before starting your ride, thoroughly inspect your mom's bike to ensure it's in good condition. Check the brakes, tires, gears, and make sure the basket is securely attached. Report any issues to the rental service to maintain safety on the campus paths. </div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Proper Locking and Storage</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box">Always lock the mom's bike securely in designated areas when not in use. Improperly stored bikes can create obstacles and safety hazards. Users are responsible for any damage or loss due to negligence in locking or storing the bike. </div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Respect Campus Regulations</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box">Adhere to the rules and guidelines set by the campus for bike usage. Follow the designated paths, speed limits, and parking rules. Complying with campus regulations is essential to maintain a safe and organized environment for everyone. </div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Timely Reporting of Issues</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box">Promptly report any damage, wear, or malfunction of the rented bike to the rental service. Timely reporting allows for quicker maintenance and ensures the safety of future users.</div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Safe Riding Practices</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box">Ride your mom's bike responsibly and considerately. Observe proper trail etiquette, maintain a safe distance from other riders and pedestrians, and avoid reckless riding behaviors. Prioritize safety while enjoying the convenience of the bike's basket. </div>
                    </div>
                        <div class="separating-line"></div>
            </div>

        <!-- 2x2 grid 3 (C4) -->
            <!-- Row 2, Column 1 -->
            <div class="heading-box">
                <h2 class="highlighted-heading">Booking Procedure</h2>
                    <div class="description-container">
                        <span class="description-text">Complete the booking form on the <a href="booking.php" style= "color: black; text-decoration: underline;">Booking Page.</a></span>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Capture a screenshot of your booking ticket.</span>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Before claiming, thoroughly inspect your rented bike.</span>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Be mindful of your payment method to prevent incurring extra charges.</span>
                    </div>
                        <div class="separating-line"></div>
            </div>

        <!-- 2x2 grid 4 (C5) -->
            <!-- Row 2, Column 2 -->
            <div class="heading-box">
                <h2 class="highlighted-heading">Return Procedure</h2>
                    <div class="description-container">
                        <span class="description-text">Report issues immediately (if any).</span>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Ensure the bike is returned before the scheduled due date and time to prevent incurring extra charges.</span>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Verify and confirm that all charges are settled on the <a href="transaction.php" style= "color: black; text-decoration: underline;">Transaction Page.</a></span>
                    </div>
                        <div class="separating-line"></div>
            </div>
        </div>
    </div>

<!-- FAQ Section (C6) -->
<div class="faq-section">
    <div class="container">
        <h2 class="faq-heading">Frequently Asked Questions</h2>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> What is a Mom's bike, and why should I consider renting one on campus?</h3>
            <p>Answer: A mom's bike is a bicycle designed with convenience in mind, featuring a basket for easy storage. It's a great choice for riders looking to transport items around the campus with ease, such as books, groceries, or personal belongings.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> Do Mom's Bikes come in different sizes?</h3>
            <p>Answer: Mom's bikes are typically designed in one-size-fits-all configurations. These bikes are adjustable to accommodate various rider heights. If you have specific size preferences, please inquire with our staff for availability.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> Are there any restrictions on what I can carry in the basket of a Mom's Bike?</h3>
            <p>Answer: While the basket on a mom's bike is designed to carry various items, we recommend avoiding exceptionally heavy or bulky cargo to maintain stability and safe handling.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> Is there a limit to how many Mom's Bikes I can rent at once?</h3>
            <p>Answer: Generally, there's no strict limit on the number of mom's bikes you can rent at once, but availability may vary. It's a good practice to reserve multiple bikes in advance for group rentals or larger events.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> Are there any specific rules for carrying passengers on a Mom's Bike?</h3>
            <p>Answer: Most mom's bikes are designed for single riders. Carrying passengers is typically discouraged due to safety concerns. You may consider renting Tandem bike for a passenger.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> Are helmets provided when renting a Mom's Bike, or should I bring my own?</h3>
            <p>Answer: While we recommend bringing your own helmet for safety, we also offer a limited supply of helmets for rent. Feel free to request one when you pick up your Mom's Bike.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> What should I do if I encounter any issues with the bike during my rental?</h3>
            <p>Answer: Swiftly report any issues to our support team so that we can assist you promptly.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> Can I rent a Mom's Bike even if I'm new to cycling or haven't ridden a bike in a long time?</h3>
            <p>Answer: Absolutely! Mom's Bikes are suitable for riders of all skill levels. If you're new to cycling, take your time to get comfortable and practice on less busy routes within the campus.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> How do I contact customer support for further assistance?</h3>
            <p>Answer: For any additional questions or assistance, you can reach our customer support at greenpath@gmail.com.</p>
        </div>
    </div>
</div>



<!-- Button for the next page (C7) -->
<div class="bike-buttons">
        <a href="mountain.php"><button class="bike-button">Mountain <i class="fas fa-bicycle"></i></button></a>
        <a href="moms.php"><button class="bike-button">Mom's <i class="fas fa-bicycle"></i></button></a>
        <a href="tandem.php"><button class="bike-button">Tandem <i class="fas fa-bicycle"></i></button></a>
    </div>
</div>





<!--- Footer Section -->
<div class="footer">
    <div class="footer-container">
        <div class="footer-row">

        <!-- Column 1 -->
        <div class="footer-col-1">
            <h3 class="footer-h3">Follow Us</h3>
            <ul class="footer-ul">
                <a href="https://www.facebook.com/profile.php?id=61552094544554&mibextid=ZbWKwL">
                    <li>
                        <img class="social-icon" src="images/ima/1/facebook.png" alt="Facebook">
                    </li>
                </a>
                <a href="https://instagram.com/greenpath_rental?igshid=MzMyNGUyNmU2YQ==">
                    <li>
                        <img class="social-icon" src="images/ima/1/insta.png" alt="Instagram">
                    </li>
                </a>
            </ul>
        </div>

        <!-- Column 2 -->
        <div class="footer-col-2">
            <img src="images/ima/1/r1.png">
            <p class="footer-p">Paving Paths for Brighter Futures</p>
        </div>

        <!-- Column 3 -->
        <div class="footer-col-3">
            <h3 class="footer-h3">Contact Us</h3>
            <p class="footer-p" style="font-weight: lighter;">greenpath@gmail.com</p><br>
            <p class="footer-p" style="font-weight: lighter;">(+63) 968-459-3721</p>
        </div>
        </div>
        <hr class="footer-hr">
        <p class="Copyright" style="font-weight: bold;">Copyright 2022</p>
    </div>
</div>
</body>
</html>