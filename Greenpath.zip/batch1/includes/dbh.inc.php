<?php

$dbServername = "localhost";
$dbUsername = "lyane";
$dbPassword = "xukai";
$dbName = "greenpath";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);