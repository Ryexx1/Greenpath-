<?php 
$success = 0;
$invalid = 0;
$user = 0;
$matchErr=0;
function startsWith($haystack, $prefixes) {
  foreach ($prefixes as $prefix) {
      $length = strlen($prefix);
      if ($length > 0 && substr($haystack, 0, $length) === $prefix) {
          return true;
      }
  }
  return false;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include('dbh.inc.php'); // Assuming your connection file is named "dbh.inc.php"
    $currentPass = $_POST['currentPass'];
    $newPass = $_POST['newPass'];
    $studno = $_POST['studno'];
    $confirmPass = $_POST['confirmPass'];
    // Check if the email ends with "@iskwela.psau.edu.ph"

    $sql = "SELECT pass FROM account WHERE studno='$studno'";
    $result = mysqli_query($conn, $sql);

    if($confirmPass != $newPass){
        $matchErr = 1;
        echo "<script> document.getElementById('error-msg').innerHTML = 'Passwords doesn\'t match';
        document.getElementById('error-msg').color = 'red';
      </script>";
   
    }else{
            if ($result) {
                $row = mysqli_fetch_assoc($result);
                if ($row) {
                    // User with the provided email exists
                    $hashedPassword = $row['pass'];
                    
                    // Check if the provided password matches the stored hashed password
                    if (password_verify($currentPass, $hashedPassword)) {
                        

                        // Generate a new hashed password for the new password
                        $newHashedPassword = password_hash($newPass, PASSWORD_DEFAULT);

                        // Update the password in the "account" table
                        $updateQuery = "UPDATE account SET pass = '$newHashedPassword' WHERE studno = '$studno'";
                        $updateResult = mysqli_query($conn, $updateQuery);

                        if ($updateResult) {
                            // Password updated successfully
                            $success = 1; // password success
                            echo "<script> alert('Password changed. Please take note of your new password');
                            window.location.href = '../settings.php';
                            </script>";
                
                        } else {
                            header("Location: ../settings.php");

                            // Handle the case where the password update fails
                            echo '<script>document.getElementById("error-msg").innerHTML = "Password update failed. Please try again later"; </script>';
                        }
                    } else {
                        $invalid = 1; // Incorrect password
                        header("Location:../ settings.php");

                        echo "<script> document.getElementById('error-msg').innerHTML = 'Incorrect Password';
                        document.getElementById('error-msg').color = 'red';
             </script>"; 
                    }
                } else {
                    $user = 1; // User does not exist
                    header("Location: ../settings.php");

                    echo "<script> document.getElementById('error-msg').innerHTML = 'User Does not Exist';
                    document.getElementById('error-msg').color = 'red';
                  </script>"; 
                }
            } else {
                header("Location: ../settings.php");
                // Handle other error cases
                echo '<script>document.getElementById("error-msg").innerHTML = "Incorrect Password"; </script>';
            }
    }
}



?>