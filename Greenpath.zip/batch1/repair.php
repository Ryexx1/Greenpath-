
<?php
$success = 0; 
$invalid = 0; 
$invalidPrefix = 0;
$notExists = 0; 
function startsWith($haystack, $prefixes) {
    foreach ($prefixes as $prefix) {
        $length = strlen($prefix);
        if ($length > 0 && substr($haystack, 0, $length) === $prefix) {
            return true;
        }
    }
    return false;
  }

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include ('../includes/dbh.inc.php');
    $BookingNo = $_POST['bookNo']; 
    $studno = $_POST['studNo'];
    $place = $_POST['place'];
    $repairType = $_POST['repairType'];
    $priorLvl = $_POST['priorLvl'];
    $comment = $_POST['comment'];
     // Check if the studno starts with C2021, C2022, C2023, or C2024
     $allowedPrefixes = ["C2021", "C2022", "C2023", "C2024"];

        if (!startsWith($studno, $allowedPrefixes)) {
            // Handle the case where studno doesn't start with the allowed prefixes
            $invalidPrefix = 1;
        } else {
            // checks only one record if the details match
            $sql = "SELECT Studno FROM booking WHERE BookingNo='$BookingNo'";
            $result = mysqli_query($conn, $sql);

            if ($result) {
                $num = mysqli_num_rows($result);

                // Check if both studno and corresponding bookingNo exist
                if ($num > 0) {
                    $row1 = mysqli_fetch_assoc($result);
                    $storedStudNo = $row1['Studno'];
                    //insert data in database if studno booked the booking number
                    if ($storedStudNo == $studno) {
                        $sql = "INSERT INTO maintenance (BookingNo, studno, place, repairType, priorLvl, comment) VALUES ('$BookingNo', '$studno', '$place', '$repairType', '$priorLvl', '$comment')";
                        $result = mysqli_query($conn, $sql);

                        if ($result) {
                            $success = 1; // form is submitted
                            
                        }
                        
                        

                    } else {
                        $invalid = 1;
                    }
                } else {
                    // Both booking number and corresponding studno do not exist
                    $notExists = 1;
                }
            }

        }  
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Maintenance</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" media="screen" href="repStyle.php">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>





</head>  
<body>
       <!-- Navbar-->
       <div class="header">
    <div class="container1">
        <div class="logo-nav-container">
            <div class="navbar">
                <nav>  
                    <ul id="MenuItems" class="center-menu">
                        <li class="pages"><a href="guidelines.php" style="color: white">Guidelines</a></li>
                        <li class="pages"><a href="catalog.php" style="color: white">Booking</a></li>
                        <li class="pages"><a href="repair.php" style="border-bottom: 2px solid white; color: white">Maintenance</a></li>
                        <li class="logo-item"><a href="index.php"><img src="images/ima/1/r1.png" alt="Logo"></a></li> 
                        <li class="pages"><a href="trans.php" style="color: white">Transaction</a></li>
                        <li class="pages"><a href="about.php" style="color: white">About Us</a></li>
                        <li class="pages"><a href="signin.php" style="color: white">Log In</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>
<!-- navbar endd -->

<div class="container">
<!-- navbar endd -->
<!-- C1-->
<div id="carouselBktBike" class="carousel slide image-section container" data-ride="carousel" data-interval="false">
  <ol class="carousel-indicators">
    <li data-target="#carouselBktBike" data-slide-to="0" class="active"></li>
    <li data-target="#carouselBktBike" data-slide-to="1"></li>
    <li data-target="#carouselBktBike" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="images/ima/3/mbike.png" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/ima/3/ibike.png" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100 " src="images/ima/3/tbike.png" alt="Third slide">
    </div>
  </div>
</div>
<br><br>
<!-- C1 END -->


<!-- C2 -->
    <!-- new section for form -->
<div class="container-form container">
    <div class="form"> 
        <!-- Repair request Form -->

        <form action=" " method="POST" >
            <h5 style="color: black">Repair Request Form</h5>
            <br>
            <div class="single-row">

            <!-- Input field for Booking Number, required -->
                <div class="single-column" id="column1">
                    <input type="text" name="bookNo" placeholder="Booking Number" required>
                    <div class="invalid-feedback">Please fill out this field.</div>
                </div>

                <!-- Input field for Booking Number, required -->
                <div class="single-column" id="column1">
                    <input type="text" name="studNo" placeholder="Student Number" required>
                    <div class="invalid-feedback">Please fill out this field.</div>
                </div>
                <!-- Dropdown for Location, required -->
                <div class="single-column" id="column2">
                    <button type="button" name="place" class="btn dropdown-toggle" id="locationDropDown" data-toggle="dropdown" data-toggle="tooltip" data-placement="top" title="Near What Location" aria-haspopup="true" aria-expanded="false" data-validation="required">
                        Location
                    </button>
                    <input type="hidden" name="place" id="placeInputLocation">
                    <div class="dropdown-menu">
                        <div class="dropdown-item" onclick="updatePlace('Library', 'placeInputLocation')">Library</div>
                        <div class="dropdown-item" onclick="updatePlace('DABEE', 'placeInputLocation')">DABEE</div>
                        <div class="dropdown-item" onclick="updatePlace('CAS', 'placeInputLocation')">CAS</div>
                        <div class="dropdown-item" onclick="updatePlace('CASTech', 'placeInputLocation')">CASTech</div>
                    </div> <!-- dropdown menu div -->
                </div>

                <!-- Dropdown for Type of Repair, required -->
                <div class="single-column" id="column3">
                    <button type="button" class="btn dropdown-toggle" id="typeOfRepDropDown" data-toggle="dropdown" data-toggle="tooltip" data-placement="top" title="What is the issue?" aria-haspopup="true" aria-expanded="false" data-validation="required">
                        Type of Repair
                    </button>
                    <input type="hidden" name="repairType" id="placeInputRepairType">
                    <div class="dropdown-menu">
                        <div class="dropdown-item" onclick="updatePlace('Wheels', 'placeInputRepairType')">Wheels</div>
                        <div class="dropdown-item" onclick="updatePlace('Handlebar', 'placeInputRepairType')">Handlebar</div>
                        <div class="dropdown-item" onclick="updatePlace('Pedal', 'placeInputRepairType')">Pedal</div>
                        <div class="dropdown-item" onclick="updatePlace('Brake Lever', 'placeInputRepairType')">Brake Lever</div>
                        <div class="dropdown-item" onclick="updatePlace('Brake', 'placeInputRepairType')">Brake</div>
                        <div class="dropdown-item" onclick="updatePlace('Frames', 'placeInputRepairType')">Frames</div>
                        <div class="dropdown-item" onclick="updatePlace('Fork', 'placeInputRepairType')">Fork</div>
                        <div class="dropdown-item" onclick="updatePlace('Hub', 'placeInputRepairType')">Hub</div>
                        <div class="dropdown-item" onclick="updatePlace('Rim', 'placeInputRepairType')">Rim</div>
                        <div class="dropdown-item" onclick="updatePlace('Chain', 'placeInputRepairType')">Chain</div>
                        <div class="dropdown-item" onclick="updatePlace('Tire', 'placeInputRepairType')">Tire</div>
                        <div class="dropdown-item" onclick="updatePlace('Seat', 'placeInputRepairType')">Seat</div>
                    </div> <!-- dropdown menu div -->
                </div>

                <!-- Dropdown for Priority Level, required -->
                <div class="single-column" id="column2">
                    <button type="button" class="btn dropdown-toggle" id="priorityDropDown" data-toggle="dropdown" data-toggle="tooltip" data-placement="top" title="Select based on the severity of the issue." aria-haspopup="true" aria-expanded="false" data-validation="required">
                        Priority Level
                    </button>
                    <input type="hidden" name="priorLvl" id="placeInputPriorityLevel">
                    <div class="dropdown-menu" >
                        <div class="dropdown-item" onclick="updatePlace('Critical', 'placeInputPriorityLevel')" data-toggle="tooltip" data-placement="top" title="Issues that directly impact safety and that could lead to accidents or injuries.">Critical Priority</div>
                        <div class="dropdown-item" onclick="updatePlace('High', 'placeInputPriorityLevel')" data-toggle="tooltip" data-placement="top" title="Problems that significantly disrupt the service and prevent users from renting bikes.">High Priority</div>
                        <div class="dropdown-item" onclick="updatePlace('Medium', 'placeInputPriorityLevel')" data-toggle="tooltip" data-placement="top" title="Issues that affect the user experience but do not pose immediate safety risks or service disruptions.">Medium Priority</div>
                        <div class="dropdown-item" onclick="updatePlace('Low', 'placeInputPriorityLevel')" data-toggle="tooltip" data-placement="top" title="Non-essential requests, like aesthetic improvements or minor issues.">Low Priority</div>
                        <div class="dropdown-item" onclick="updatePlace('Scheduled', 'placeInputPriorityLevel')" data-toggle="tooltip" data-placement="top" title="Regular, planned maintenance tasks to ensure the long-term reliability and efficiency of the system.">Scheduled Maintenance</div>
                    </div> <!-- dropdown menu div -->
                </div>



                <!-- Input field for comment, required -->
                <div class="single-column" id="column4">
                    <textarea name="comment" placeholder="Comment" id="comment" required></textarea>
                    <div class="valid-feedback">Valid.</div>
                    <div class="invalid-feedback">Please fill out this field.</div>
                 </div>
            </div>
            
        
            <!-- Submit button -->
            <input type="submit" value="SUBMIT" id="btn" />
            <br>
            <span id="error-msg"></span>
        </form>
    </div> 
</div>
</div>


<!--- Footer Section -->
<div class="footer">
    <div class="footer-container">
        <div class="footer-row">

        <!-- Column 1 -->
        <div class="footer-col-1">
            <h3 class="footer-h3">Follow Us</h3>
            <ul class="footer-ul">
                <a href="https://www.facebook.com/profile.php?id=61552094544554&mibextid=ZbWKwL">
                    <li>
                        <img class="social-icon" src="images/ima/1/facebook.png" alt="Facebook">
                    </li>
                </a>
                <a href="https://instagram.com/greenpath_rental?igshid=MzMyNGUyNmU2YQ==">
                    <li>
                        <img class="social-icon" src="images/ima/1/insta.png" alt="Instagram">
                    </li>
                </a>
            </ul>
        </div>

        <!-- Column 2 -->
        <div class="footer-col-2">
            <img src="images/ima/1/r1.png">
            <p class="footer-p">Paving Paths for Brighter Futures</p>
        </div>

        <!-- Column 3 -->
        <div class="footer-col-3">
            <h3 class="footer-h3">Contact Us</h3>
            <p class="footer-p" style="font-weight: lighter;">greenpath@gmail.com</p><br>
            <p class="footer-p" style="font-weight: lighter;">(+63) 968-459-3721</p>
        </div>
        </div>
        <hr class="footer-hr">
        <p class="Copyright" style="font-weight: bold;">Copyright 2022</p>
    </div>
</div>


<?php
if($success){
    echo '<script> alert("Repair Request Submitted"); </script>';
}
if($invalid){
    echo '<script>document.getElementById("error-msg").innerHTML = "Wrong Credentials"</script>'; 
}
if($notExists){
    echo '<script>document.getElementById("error-msg").innerHTML = "Booking Record Doesn\'t exists" </script>';
}

?>
<script src="../js/rep.js"></script>

</body>    
</html>
