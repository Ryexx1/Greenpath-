<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Mountain Bike</title>
    <link rel="stylesheet" type="text/css" media="screen" href="bike.php">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

  <!-- Link to the Font Awesome CSS -->
  <script src="https://kit.fontawesome.com/67cac72898.js" crossorigin="anonymous"></script>
</head>  
<body>





<!-- Navbar-->
<div class="header">
    <div class="container">
        <div class="logo-nav-container">
            <div class="navbar">
                <nav>  
                    <ul id="MenuItems" class="center-menu">
                        <li class="pages"><a href="guidelines.php" style="border-bottom: 2px solid white">Guidelines</a></li>
                        <li class="pages"><a href="catalog.php">Booking</a></li>
                        <li class="pages"><a href="repair.php">Maintenance</a></li>
                        <li class="logo-item"><a href="index.php"><img src="images/ima/1/r1.png" alt="Logo"></a></li>
                        <li class="pages"><a href="trans.php">Transaction</a></li>
                        <li class="pages"><a href="about.php">About Us</a></li>
                        <li class="pages"><a href="signin.php">Log In</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>



<!-- distinction (C1) -->
<div class="paragraph-section">
    <div class="container">
        <h1> Ride The Heights: Navigate The Campus with Precision and Power</h1>
        <p class="paragraph-text">
        The Mountain Bike, a versatile and rugged companion for campus navigation in our bike rental system, 
        offers an exhilarating blend of performance and eco-friendly mobility. Designed for students seeking 
        a dynamic mode of transportation, these bikes effortlessly tackle both hilly paths and flat roads, 
        providing a seamless and efficient journey across campus. With its sturdy build, the Mountain Bike ensures 
        stability and durability, making it an ideal choice for diverse terrains found on university grounds. 
        Experience the joy of navigating through scenic campus landscapes as the Mountain Bike empowers riders 
        to explore their surroundings with ease. Choose sustainability and adventure, make the Mountain Bike 
        your trusted companion for a greener and more enjoyable campus commute.
        </p>
    </div>
</div>

    <div class="content-container">
        <!-- Left Column with "mbike" -->
        <div class="left-column">
            <img id="mbike" src="images/ima/3/mbike.png" alt="Your Image">
        </div>

        <!-- 2x2 grid 1 (C2) -->
        <div class="right-column">
            <!-- Row 1, Column 1 -->
            <div class="heading-box">
                <h2 class="highlighted-heading">Safety Guidelines</h2>
                    <div class="description-container">
                        <span class="description-text">Check Your Brakes</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box">Squeeze both brake levers to ensure your brakes are responsive. If the bike doesn't stop smoothly, don't ride it. Adequate braking is crucial for your safety on the trails. <br> <a href="index.php" style= "color: white; text-decoration: underline;">Here's how to:</a></div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Inspect Tire Pressure</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box"> Press on the tires with your thumb. They should feel firm to the touch. Underinflated tires can make riding difficult and potentially lead to flats. Use a bike pump to reach the recommended tire pressure, usually marked on the tire sidewall. <br> <a href="index.php" style= "color: white; text-decoration: underline;">Here's how to:</a></div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Wear Protective Gear</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box"> For added safety, always wear a properly fitted helmet. Additional protective gear such as gloves, knee and elbow pads, and eyewear can provide extra protection while on the trail. <br> <a href="index.php" style= "color: white; text-decoration: underline;">Here's how to:</a></div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Familiarize Yourself with Gears</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box"> Mountain bikes often come with multiple gears. Learn how to shift gears before your ride to make ascending and descending hills more manageable. <br> <a href="index.php" style= "color: white; text-decoration: underline;">Here's how to:</a></div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Ride Within Your Skill Level</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box"> Choose paths and routes on campus that align with your current skill level. If you're new to the campus, begin with simpler routes, and over time, advance to more complex ones as you become more familiar with the surroundings. <br> <a href="index.php" style= "color: white; text-decoration: underline;">Here's how to:</a></div>
                    </div>
                        <div class="separating-line"></div>
            </div>
        
        <!-- 2x2 grid 2 (C3) -->
            <!-- Row 1, Column 2 -->
            <div class="heading-box">
                <h2 class="highlighted-heading">User Responsibility</h2>
                    <div class="description-container">
                        <span class="description-text">Bike Inspection</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box">Before using the mountain bike, perform a thorough inspection to ensure it's in good condition. Check the brakes, tires, gears, and any accessories. Report any issues to the rental service to prevent accidents.</div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Proper Locking and Storage</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box">Always lock the mountain bike securely in designated areas when not in use. Improperly stored bikes can create obstacles and safety hazards. Users are responsible for any damage or loss due to negligence in locking or storing the bike.</div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Respect Campus Regulations</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box">Adhere to all designated trail rules and regulations. Follow the prescribed paths and respect any off-limit areas within the campus. Failure to comply may result in fines and potential damage liability.</div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Timely Reporting of Issues</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box">Promptly report any damage, wear, or malfunction of the rented bike to the rental service. Timely reporting allows for quicker maintenance and ensures the safety of future users.</div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Safe Riding Practices</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box">Ride the mountain bike responsibly and considerately. Observe proper trail etiquette, yield to pedestrians, and maintain a safe distance from other riders. Reckless riding, such as performing stunts or riding at excessive speeds, is prohibited and may result in penalties or fines. Always prioritize the safety of yourself and others while enjoying the campus trails.</div>
                    </div>
                        <div class="separating-line"></div>
            </div>

        <!-- 2x2 grid 3 (C4) -->
            <!-- Row 2, Column 1 -->
            <div class="heading-box">
                <h2 class="highlighted-heading">Booking Procedure</h2>
                    <div class="description-container">
                        <span class="description-text">Complete the booking form on the <a href="booking.php" style= "color: black; text-decoration: underline;">Booking Page.</a></span>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Capture a screenshot of your booking ticket.</span>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Before claiming, thoroughly inspect your rented bike.</span>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Be mindful of your payment method to prevent incurring extra charges.</span>
                    </div>
                        <div class="separating-line"></div>
            </div>

        <!-- 2x2 grid 4 (C5) -->
            <!-- Row 2, Column 2 -->
            <div class="heading-box">
                <h2 class="highlighted-heading">Return Procedure</h2>
                    <div class="description-container">
                        <span class="description-text">Report issues immediately (if any).</span>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Ensure the bike is returned before the scheduled due date and time to prevent incurring extra charges.</span>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Verify and confirm that all charges are settled on the <a href="transaction.php" style= "color: black; text-decoration: underline;">Transaction Page.</a></span>
                    </div>
                        <div class="separating-line"></div>
            </div>
        </div>
    </div>

<!-- FAQ Section (C6) -->
<div class="faq-section">
    <div class="container">
        <h2 class="faq-heading">Frequently Asked Questions</h2>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> What is a Mountain bike, and why should I consider renting one on campus?</h3>
            <p>Answer: A mountain bike for campus navigation operates as a versatile, off-road bicycle designed to help riders traverse various natural terrains within the campus environment.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> What are the rental hours for the bikes?</h3>
            <p>Answer: Our bike rental service operates from 7 am to 6 pm, Monday to Saturday. You can pick up and return your rented bike within these hours.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> Can anyone rent a Mountain bike?</h3>
            <p>Answer: Yes, our rental service is available to all campus members, including students, staff, teachers, and administrators.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> What types of bikes can I rent on campus?</h3>
            <p>Answer: You can rent mountain bikes, mom's bikes, and tandem bikes for campus navigation.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> What is the minimum rental duration?</h3>
            <p>Answer: The minimum rental duration is one day, but you can choose to rent for longer periods if needed.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> How can I pay for my bike rental?</h3>
            <p>Answer: You can pay for your bike rental to our staff who manage the bike rental system. Simply provide your e-ticket, and our staff will assist you in validating the payment and getting you set up with your rented bike.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> What should I do if I encounter any issues with the bike during my rental?</h3>
            <p>Answer: Swiftly report any issues to our support team so that we can assist you promptly.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> Is protective gear provided with the rental bike?</h3>
            <p>Answer: We recommend riders to bring their own protective gear, but we also have a limited supply of helmets available for rental upon request.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> Are there any extra fees to be aware of?</h3>
            <p>Answer: Be mindful of your chosen payment method to avoid any additional fees. Check your transaction page to verify and confirm all charges.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> Can I rent a bike for a group or event?</h3>
            <p>Answer: Yes, we can accommodate group rentals for events or classes. Please contact us in advance to make arrangements.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> How do I contact customer support for further assistance?</h3>
            <p>Answer: For any additional questions or assistance, you can reach our customer support at greenpath@gmail.com.</p>
        </div>
    </div>
</div>

<!-- Button for the next page (C7) -->
<div class="bike-buttons">
        <a href="mountain.php"><button class="bike-button">Mountain <i class="fas fa-bicycle"></i></button></a>
        <a href="moms.php"><button class="bike-button">Mom's <i class="fas fa-bicycle"></i></button></a>
        <a href="tandem.php"><button class="bike-button">Tandem <i class="fas fa-bicycle"></i></button></a>
    </div>
</div>





<!--- Footer Section -->
<div class="footer">
    <div class="footer-container">
        <div class="footer-row">

        <!-- Column 1 -->
        <div class="footer-col-1">
            <h3 class="footer-h3">Follow Us</h3>
            <ul class="footer-ul">
                <a href="https://www.facebook.com/profile.php?id=61552094544554&mibextid=ZbWKwL">
                    <li>
                        <img class="social-icon" src="images/ima/1/facebook.png" alt="Facebook">
                    </li>
                </a>
                <a href="https://instagram.com/greenpath_rental?igshid=MzMyNGUyNmU2YQ==">
                    <li>
                        <img class="social-icon" src="images/ima/1/insta.png" alt="Instagram">
                    </li>
                </a>
            </ul>
        </div>

        <!-- Column 2 -->
        <div class="footer-col-2">
            <img src="images/ima/1/r1.png">
            <p class="footer-p">Paving Paths for Brighter Futures</p>
        </div>

        <!-- Column 3 -->
        <div class="footer-col-3">
            <h3 class="footer-h3">Contact Us</h3>
            <p class="footer-p" style="font-weight: lighter;">greenpath@gmail.com</p><br>
            <p class="footer-p" style="font-weight: lighter;">(+63) 968-459-3721</p>
        </div>
        </div>
        <hr class="footer-hr">
        <p class="Copyright" style="font-weight: bold;">Copyright 2022</p>
    </div>
</div>
</body>
</html>