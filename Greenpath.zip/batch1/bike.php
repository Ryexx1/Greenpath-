<?php header("Content-type: text/css"); ?>
/* Reset styles for all elements */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Global styles for the body */
body {
    background-color: white;
    font-family: Trebuchet MS, sans-serif;
}





/* NAVBAR */
/* Styles for the logo image */
.logo-item img {
    width: 90px;
    height: auto;
    margin-left: 150px;
    margin-right: 150px;
}

/* Center the navigation menu items */
.center-menu {
    list-style-type: none;
    display: flex;
    justify-content: center;
    align-items: center;
}

.pages {
    margin-right: 25px; 
    margin-left: 25px; 
    font-size: 16px;
    font-family: Trebuchet MS, sans-serif;
}

.pages:hover{
    background: rgba(255, 255, 255, 0.2);
    padding: 15px 0 15px 0;
}

/* Styles for anchor links */
a {
    text-decoration: none;
    color: #000000;
    font-family: Trebuchet MS, sans-serif;
    color: white;
    padding: 0 5px 0 5px;
}

.container {
    max-width: 1300px;
    margin: auto;
    padding-left: 25px;
    padding-right: 25px;
}

.header{
    background-color: #062644;
    margin-bottom: 50px;
}



/* C1 */
h1 {
    text-align: center; 
    margin-bottom:20px;
    font-size: 24px; /* Adjust the font size as needed */
    font-weight: bold; /* Optional: Add font weight for emphasis */
    color: black; /* Set the desired text color */
    font-family: Trebuchet MS, sans-serif;
}

/* Style for the paragraph text */
.paragraph-text {
    font-size: 16px;
    line-height: 1.8;
    text-align: center;
    max-width: 1000px;
    margin: 0 auto;
    color: black;
    font-family: Trebuchet MS, sans-serif;
}

/* Content Section */
.content-container {
    display: flex;
    margin-top: 30px;
}

/* Left Column */
.left-column {
    flex: 1;
    padding: 20px;
}

#mbike {
    max-width: 100%;
    height: auto;
    border-radius: 50px;
}

.left-column {
    flex: 1;
    padding: 0 0 0 100px;
}


/* C2, C3, C4, C5 */
/* Right Column (2x2 grid) */
.right-column {
    flex: 1;
    display: grid;
    grid-template-columns: 1fr 1fr;
    grid-gap: 40px;
    padding: 0 80px 0 0;
}

/* Style for heading boxes with text */
.heading-box {
    text-align: center;
    position: relative;
}

.heading-box p {
    font-size: 16px;
    margin-top: 10px;
}

.image-description {
    cursor: pointer;
    padding: 5px 0 5px 30px;
    margin: 0 5px 0 5px;
    text-align: left;
}

.description-text {
    font-size: 14px;
}

.text-box {
    display: none;
    font-size: 12px;
    text-align: justify;
    width: 90%;
    margin-left: 20px;
}

.description-container {
    position: relative;
    cursor: pointer;
    padding: 5px 0 5px 30px;
    margin: 5px 5px 5px 5px;
    text-align: left;
}

/* Position the text-box relative to the container when hovered */
.description-container:hover .text-box {
    display: block;
    position: absolute;
    left: 0;
    top: 100%;
    background: #062644;
    border-radius: 15px;
    color: white;
    padding: 20px;
    border: 1px solid #ddd;
    z-index: 1;
    min-width: 200px;
}

/* Styles for the highlighted heading */
.highlighted-heading {
    background-color: #f18a06;
    color: white;
    padding: 10px 10px 10px 10px;
    border-radius: 10px;
    display: inline-block;
    font-size: 20px;
}

.separating-line {
    border-top: 1px solid #b5b5b5;
    width: 85%;
    margin: 0 0 0 30px;
}



/* C6 */
h2{
    font-size: 20px;
    padding: 50px 0 0 50px;
}

#quest{
    font-size: 18px;
    padding: 20px 0 0 50px;
}

.faq-question p{
    padding: 0 50px 0 80px;
    font-size: 16px;
}



/* C7 */
.bike-buttons {
    text-align: center;
    margin-top: 50px;
}

/* Style for each button */
.bike-button {
    background-color: #062644;
    color: white;
    padding: 15px 30px;
    border-radius: 10px;
    font-weight: bold;
    font-family: Trebuchet MS, sans-serif;
    letter-spacing: 3px;
    margin: 0 15px;
    cursor: pointer;
    border: 2px solid white;
}

.bike-button:hover {
    background-color: #142b61;
    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.3);
}





/* Footer styles */
/* Styling for the footer container */
.footer {
    background: #062644;
    color: white;
    font-size: 16px;
    text-align: center;
    padding: 40px 0;
    margin-top: 50px;
}

/* Styling for paragraphs within the footer */
.footer-p {
    color: white;
    font-weight: bold;
}

/* Styling for footer heading */
.footer-h3 {
    color: white;
    padding-top: 30px;
    margin-bottom: 20px;
    font-size: 20px;
    font-weight: bold;
}

/* Styling for the footer container */
.footer-container {
    margin: auto;
    max-width: 1000px;
    padding-left: 5px;
    padding-right: 5px;
}

/* Styling for the row in the footer */
.footer-row {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: space-around;
}

/* Styling for the first column in the footer */
.footer-col-1 {
    min-height: 200px;
    margin-bottom: 20px;
    font-family: Trebuchet MS, sans-serif;
    flex-basis: 12%;
    text-align: center;
}

/* Styling for social media icons */
.social-icon {
    width: 90px;
    height: 90px;
}

/* Styling for the second column in the footer */
.footer-col-2 {
    padding-left: 5px;
    min-height: 200px;
    margin-bottom: 20px;
    flex: 1;
    font-family: Trebuchet MS, sans-serif;
    text-align: center;
}

/* Styling for images in the second column of the footer */
.footer-col-2 img {
    width: 180px;
    margin-bottom: 20px;
}

/* Styling for the third column in the footer */
.footer-col-3 {
    min-height: 200px;
    margin-bottom: 10px;
    font-family: Trebuchet MS, sans-serif;
    flex-basis: 12%;
    text-align: center;
}

/* Styling for the footer unordered list */
.footer-ul {
    list-style-type: none;
    display: flex;
    list-style: none;
    padding: 0;
}

/* Styling for list items in the footer unordered list */
.footer-ul li {
    margin-right: 1px;
}

/* Styling for the horizontal rule in the footer */
.footer-hr {
    border: none;
    background: #b5b5b5;
    height: 1px;
    margin: 20px 0;
}

/* Styling for the copyright text in the footer */
.Copyright {
    font-size: 12px;
    text-align: center;
    font-family: Trebuchet MS, sans-serif;
}