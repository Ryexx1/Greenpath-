<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Index</title>
    <link rel="stylesheet" type="text/css" media="screen" href="instyle.php">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>  
<body>





<!-- Navbar-->
<div class="header">
    <div class="container">
        <div class="logo-nav-container">
            <div class="navbar">
                <nav>  
                    <ul id="MenuItems" class="center-menu">
                        <li class="pages"><a href="guidelines.php">Guidelines</a></li>
                        <li class="pages"><a href="catalog.php">Booking</a></li>
                        <li class="pages"><a href="repair.php">Maintenance</a></li>
                        <li class="logo-item"><a href="index.php"><img src="images/ima/1/r1.png" alt="Logo"></a></li>
                        <li class="pages"><a href="trans.php">Transaction</a></li>
                        <li class="pages"><a href="about.php">About Us</a></li>
                        <li class="pages"><a href="signin.php">Log In</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>



<!-- Image, text, and button (C1) -->
<div class="image-section">
    <div class="container">
        <div class="image-content">
            <div class="text-and-button">
                <h1>Ride Green Towards <br> Your Dreams</h1>
                <p i="pedal">Pedal for progress as you pursue your passions.</p>
                <p i="pedal">Contribute to cultivating greener campuses and</p>
                <p i="pedal">stride towards a sustainable future.</p>
                <a href="learn.php" class="btn">Learn More</a>
            </div>
            <div class="image">
                <img src="images/ima/2/sust.png" alt="Your Image">
            </div>
        </div>
    </div>
</div>



<!-- Icons with descriptions (C2) -->
<div class="image-icons">
    <div class="icon-container">
        <img src="images/ima/2/C.png" alt="Icon 1">
        <p>Biking on campus provides a swift way to move between 
        classes and appointments, saving you valuable time.</p>
    </div>
    <hr class="icon-divider">
    <div class="icon-container">
        <img src="images/ima/2/Z.png" alt="Icon 2">
        <p>Pedal for progress and better health, 
        benefiting both you and the planet.</p>
    </div>
    <hr class="icon-divider">
    <div class="icon-container">
        <img src="images/ima/2/V.png" alt="Icon 3">
        <p>Fewer cars and reduced traffic mean a 
        quieter, cleaner, and more enjoyable campus
        environment for everyone.</p>
    </div>
    <hr class="icon-divider">
    <div class="icon-container">
        <img src="images/ima/2/X.png" alt="Icon 4">
        <p>Bike commuting is eco-friendly and emission-free, 
        reducing your carbon footprint sustainably.</p>
    </div>
</div>



<!-- Bike Images Section (C3) -->
<div class="bike-images">
    <div class="bike">
        <img src="images/ima/2/mb.jpg" alt="Bike 1">
        <h3>Mountain Bike</h3>
        <div class="caption">
            <p>Discover the ideal fusion of rugged performance and eco-friendly campus transportation with our Mountain Bikes.
            Effortlessly navigate hilly paths and flat roads, savoring every moment of campus beauty and efficiency.</p>
        </div>
    </div>
    <div class="bike">
        <img src="images/ima/2/sb.jpg" alt="Bike 2">
        <h3>Mom's Bike</h3>
        <div class="caption">
            <p>Discover the convenience of Mom's Bike, which has a spacious front basket for effortless carrying
            of books, things and more. Say good-bye to heavy baggage and hello to stress-free commuting.</p>
        </div>
    </div>
    <div class="bike">
        <img src="images/ima/2/db.png" alt="Bike 3">
        <h3>Tandem Bike</h3>
        <div class="caption">
            <p>Take advantage of the fun of riding on campus with a friend on our tandem bike, built for two-seat adventures. 
            This unique bike fosters companionship as you explore the campus's surroundings.</p>
        </div>
    </div>
</div>



<!-- Animated Bike Image with Random Trivia (C4)-->
<div class="animated-bike-container">
    <div class="animated-bike" onclick="showRandomBikeTrivia()">
        <img src="images/ima/2/55.png" alt="Bike Image" class="bike-image">
        <button onclick="showRandomBikeTrivia()" class="trivia-button">Did you know?</button>
    </div>

    <!-- Modal for displaying trivia -->
    <div id="triviaModal" class="modal">
        <div class="modal-content">
            <p id="triviaText"></p>
        </div>
    </div>
</div>

<!-- Function to generate and display random bike trivia -->
<script>
    // Array of bike trivia messages
    const bikeTrivia = [
        "Biking improves cardiovascular health!",
        "Cycling can help reduce stress and boost mood.",
        "A 30-minute bike ride can significantly boost energy.",
        "Biking is a fun way to explore and connect with nature.",
        "Biking promotes a healthier planet by reducing carbon emissions.",
        "Bike commuting is a sustainable choice, contributing to a greener and cleaner Earth.",
        "Cycling is an eco-friendly mode of transportation, minimizing the ecological footprint.",
        "Biking reduces traffic congestion, leading to less noise and air pollution.",
        "By cycling, you're actively participating in the preservation of our planet for future generations.",
        "The energy and materials required to manufacture a bike are significantly less than those for a car, promoting resource efficiency.",
        "Mountain Biking engages various muscle groups, providing both a cardiovascular and strength-building workout.",
        "Mountain Bikes are designed for rugged performance, making them ideal for navigating hilly paths and flat roads.",
        "Designed for efficiency, Mom's Bike offers a stress-free commute while contributing to environmental sustainability.",
        "Bikes with front baskets are particularly associated with Dutch cycling culture. In the Netherlands, it is common to see people of all ages using bikes with front baskets for everyday errands and commuting.",
        "Tandem bikes are more efficient than regular bicycles because two riders can work together to generate power. This means that tandem bikes can travel faster and cover longer distances with less effort compared to individual bikes.",
        "Tandem bikes can be beneficial for individuals with disabilities or visual impairments who may not be able to ride a regular bike independently. It allows them to experience the joy of cycling with the assistance of a partner.",
    ];

    function showRandomBikeTrivia() {
        // Shuffle the array to make trivia messages random
        const shuffledTrivia = shuffleArray(bikeTrivia);

        // Display a random trivia message in the modal
        const randomTrivia = shuffledTrivia[0];
        document.getElementById('triviaText').innerHTML = randomTrivia;
        openTriviaModal();
    }

    function openTriviaModal() {
        const modal = document.getElementById('triviaModal');
        modal.style.display = 'block';

        // Close modal if user clicks anywhere outside of it
        window.onclick = function (event) {
            if (event.target === modal) {
                closeTriviaModal();
            }
        };
    }

    function closeTriviaModal() {
        document.getElementById('triviaModal').style.display = 'none';
        // Remove the window.onclick event when the modal is closed
        window.onclick = null;
    }

    // Function to shuffle an array using the Fisher-Yates algorithm
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }
</script>





<!--- Footer Section -->
<div class="footer">
    <div class="footer-container">
        <div class="footer-row">

        <!-- Column 1 -->
        <div class="footer-col-1">
            <h3 class="footer-h3">Follow Us</h3>
            <ul class="footer-ul">
                <a href="https://www.facebook.com/profile.php?id=61552094544554&mibextid=ZbWKwL">
                    <li>
                        <img class="social-icon" src="images/ima/1/facebook.png" alt="Facebook">
                    </li>
                </a>
                <a href="https://instagram.com/greenpath_rental?igshid=MzMyNGUyNmU2YQ==">
                    <li>
                        <img class="social-icon" src="images/ima/1/insta.png" alt="Instagram">
                    </li>
                </a>
            </ul>
        </div>

        <!-- Column 2 -->
        <div class="footer-col-2">
            <img src="images/ima/1/r1.png">
            <p class="footer-p">Paving Paths for Brighter Futures</p>
        </div>

        <!-- Column 3 -->
        <div class="footer-col-3">
            <h3 class="footer-h3">Contact Us</h3>
            <p class="footer-p" style="font-weight: lighter;">greenpath@gmail.com</p><br>
            <p class="footer-p" style="font-weight: lighter;">(+63) 968-459-3721</p>
        </div>
        </div>
        <hr class="footer-hr">
        <p class="Copyright" style="font-weight: bold;">Copyright 2022</p>
    </div>
</div>
</body>
</html>