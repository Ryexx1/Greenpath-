<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Tandem Bike</title>
    <link rel="stylesheet" type="text/css" media="screen" href="bike.php">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

  <!-- Link to the Font Awesome CSS -->
  <script src="https://kit.fontawesome.com/67cac72898.js" crossorigin="anonymous"></script>
</head>  
<body>





<!-- Navbar-->
<div class="header">
    <div class="container">
        <div class="logo-nav-container">
            <div class="navbar">
                <nav>  
                    <ul id="MenuItems" class="center-menu">
                        <li class="pages"><a href="guidelines.php" style="border-bottom: 2px solid white">Guidelines</a></li>
                        <li class="pages"><a href="catalog.php">Booking</a></li>
                        <li class="pages"><a href="repair.php">Maintenance</a></li>
                        <li class="logo-item"><a href="index.php"><img src="images/ima/1/r1.png" alt="Logo"></a></li>
                        <li class="pages"><a href="trans.php">Transaction</a></li>
                        <li class="pages"><a href="about.php">About Us</a></li>
                        <li class="pages"><a href="signin.php">Log In</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>



<!-- distinction (C1) -->
<div class="paragraph-section">
    <div class="container">
    <h1> Double the Fun: Enhancing Campus Mobility and Connection</h1>
        <p class="paragraph-text">
        The tandem bike, an exciting addition to our campus bike rental system, 
        is designed to revolutionize the way students navigate the university grounds. 
        Offering a unique two-seat configuration, the tandem bike encourages shared experiences, 
        fostering camaraderie among riders as they explore the campus together. Ideal for group 
        outings or recreational rides, this bike promotes a sense of community and collaboration. 
        Its efficient design not only facilitates eco-friendly transportation but also contributes 
        to reduced traffic congestion on campus, creating a quieter and more enjoyable environment 
        for everyone. Embrace the joy of tandem biking for a fun and sustainable way to traverse 
        the university landscape with a friend or fellow student.
        </p>
    </div>
</div>

    <div class="content-container">
        <!-- Left Column with "mbike" -->
        <div class="left-column">
            <img id="mbike" src="images/ima/3/tbike.png" alt="Your Image">
        </div>

        <!-- 2x2 grid 1 (C2) -->
        <div class="right-column">
            <!-- Row 1, Column 1 -->
            <div class="heading-box">
                <h2 class="highlighted-heading">Safety Guidelines</h2>
                    <div class="description-container">
                        <span class="description-text">Inspect the Tandem Bike</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box"> Before starting your tandem bike ride, perform a comprehensive inspection of the entire bike. Check both seats, pedals, chains, brakes, and tires to ensure they are in proper working condition. Make sure the bike is well-maintained and safe for two riders. <br> <a href="index.php" style= "color: white; text-decoration: underline;">Here's how to:</a></div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Coordinate with Your Partner</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box"> Effective communication and coordination with your tandem bike partner are essential. Agree on a set of signals or commands to indicate stops, starts, and turns. Smooth coordination helps prevent sudden jolts or accidents during the ride. <br> <a href="index.php" style= "color: white; text-decoration: underline;">Here's how to:</a></div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Balance and Weight Distribution</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box"> Achieving and maintaining proper balance on a tandem bike is crucial. The front rider should keep a steady pace and maintain a firm grip on the handlebars. The rear rider should avoid sudden movements or excessive leaning, as this can affect balance. Distribute your weight evenly to ensure stability. <br> <a href="index.php" style= "color: white; text-decoration: underline;">Here's how to:</a></div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Braking and Stopping Safely</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box"> Both riders must be aware of the braking system. Ensure that both riders are comfortable with the brakes and know when and how to apply them. When coming to a stop, communicate clearly and start braking well in advance to avoid sudden halts. <br> <a href="index.php" style= "color: white; text-decoration: underline;">Here's how to:</a></div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Mind the Turning Radius</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box"> Tandem bikes have a larger turning radius compared to single bikes. Take extra caution when navigating turns and curves, especially at slower speeds. Lean into turns together and anticipate the need for additional space to avoid obstacles. <br> <a href="index.php" style= "color: white; text-decoration: underline;">Here's how to:</a></div>
                    </div>
                        <div class="separating-line"></div>
            </div>
        
        <!-- 2x2 grid 2 (C3) -->
            <!-- Row 1, Column 2 -->
            <div class="heading-box">
                <h2 class="highlighted-heading">User Responsibility</h2>
                    <div class="description-container">
                        <span class="description-text">Bike Inspection</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box">Before starting your ride, thoroughly inspect the rented tandem bike to ensure it's in good condition. Check for any issues with brakes, tires, gears, and other components. If you notice any problems or damage, promptly report them to the rental service to ensure safety for the next users. </div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Proper Locking and Storage</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box">Always lock the tandem bike securely in designated areas when not in use. Improperly stored bikes can create obstacles and safety hazards. Users are responsible for any damage or loss due to negligence in locking or storing the bike. </div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Respect Campus Regulations</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box">Adhere to the rules and guidelines set by the campus for bike usage. Follow the designated paths, speed limits, and parking rules. Complying with campus regulations is essential to maintain a safe and organized environment for everyone. </div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Timely Reporting of Issues</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box">Promptly report any damage, wear, or malfunction of the rented bike to the rental service. Timely reporting allows for quicker maintenance and ensures the safety of future users.</div>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Safe Riding Practices</span>
                        <i class="fas fa-caret-down" style="margin-left: 10px;"></i>
                        <div class="text-box">Ride the tandem bike responsibly and considerately. Observe proper trail etiquette, maintain a safe distance from other riders and pedestrians, and avoid reckless riding behaviors. Prioritize safety while enjoying the tandem bike experience, and ensure both riders communicate effectively for a safe journey. </div>
                    </div>
                        <div class="separating-line"></div>
            </div>

        <!-- 2x2 grid 3 (C4) -->
            <!-- Row 2, Column 1 -->
            <div class="heading-box">
                <h2 class="highlighted-heading">Booking Procedure</h2>
                    <div class="description-container">
                        <span class="description-text">Complete the booking form on the <a href="booking.php" style= "color: black; text-decoration: underline;">Booking Page.</a></span>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Capture a screenshot of your booking ticket.</span>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Before claiming, thoroughly inspect your rented bike.</span>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Be mindful of your payment method to prevent incurring extra charges.</span>
                    </div>
                        <div class="separating-line"></div>
            </div>

        <!-- 2x2 grid 4 (C5) -->
            <!-- Row 2, Column 2 -->
            <div class="heading-box">
                <h2 class="highlighted-heading">Return Procedure</h2>
                    <div class="description-container">
                        <span class="description-text">Report issues immediately (if any).</span>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Ensure the bike is returned before the scheduled due date and time to prevent incurring extra charges.</span>
                    </div>
                        <div class="separating-line"></div>

                    <div class="description-container">
                        <span class="description-text">Verify and confirm that all charges are settled on the <a href="transaction.php" style= "color: black; text-decoration: underline;">Transaction Page.</a></span>
                    </div>
                        <div class="separating-line"></div>
            </div>
        </div>
    </div>

<!-- FAQ Section (C6) -->
<div class="faq-section">
    <div class="container">
        <h2 class="faq-heading">Frequently Asked Questions</h2>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> What is a Tandem bike, and why should I consider renting one on campus?</h3>
            <p>Answer: A Tandem Bike is a bicycle designed for two riders, with one rider in the front (captain) and another in the rear (stoker) seat. Renting a Tandem bike on campus provides an efficient, eco-friendly, and fun way for two people to travel together, encouraging teamwork and bonding while reducing the carbon footprint.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> Is it necessary for both riders to pedal on a Tandem Bike?</h3>
            <p>Answer: Yes, both riders should pedal together to provide power and balance. It's essential for coordination and a smooth riding experience.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> Are Tandem Bikes suitable for riders of different heights and weights?</h3>
            <p>Answer: Tandem Bikes are adjustable to accommodate riders of varying heights. It's important to adjust the seats and handlebars to ensure both riders are comfortable. Weight limits may vary, so check with the rental service for specific guidelines.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> Do Tandem Bikes require special riding skills?</h3>
            <p>Answer: While riding a tandem bike doesn't necessarily require special skills, communication between riders is crucial. Coordination, communication, and trust are key to a safe and enjoyable ride.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> Can I rent a Tandem Bike if my riding partner is inexperienced?</h3>
            <p>Answer:  Yes, Tandem Bikes are suitable for riders of different skill levels. If your partner is inexperienced, take the time to communicate and practice safe riding habits together.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> Are helmets provided when renting a Tandem Bike, or should I bring my own?</h3>
            <p>Answer: While we recommend bringing your own helmet for safety, we also offer a limited supply of helmets for rent. Feel free to request one when you pick up your Mom's Bike.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> What should I do if I encounter any issues with the bike during my rental?</h3>
            <p>Answer: Swiftly report any issues to our support team so that we can assist you promptly.</p>
        </div>
        <div class="faq-question">
            <h3 id="quest"><i class="fas fa-bicycle"></i> How do I contact customer support for further assistance?</h3>
            <p>Answer: For any additional questions or assistance, you can reach our customer support at greenpath@gmail.com.</p>
        </div>
    </div>
</div>



<!-- Button for the next page (C7) -->
<div class="bike-buttons">
        <a href="mountain.php"><button class="bike-button">Mountain <i class="fas fa-bicycle"></i></button></a>
        <a href="moms.php"><button class="bike-button">Mom's <i class="fas fa-bicycle"></i></button></a>
        <a href="tandem.php"><button class="bike-button">Tandem <i class="fas fa-bicycle"></i></button></a>
    </div>
</div>





<!--- Footer Section -->
<div class="footer">
    <div class="footer-container">
        <div class="footer-row">

        <!-- Column 1 -->
        <div class="footer-col-1">
            <h3 class="footer-h3">Follow Us</h3>
            <ul class="footer-ul">
                <a href="https://www.facebook.com/profile.php?id=61552094544554&mibextid=ZbWKwL">
                    <li>
                        <img class="social-icon" src="images/ima/1/facebook.png" alt="Facebook">
                    </li>
                </a>
                <a href="https://instagram.com/greenpath_rental?igshid=MzMyNGUyNmU2YQ==">
                    <li>
                        <img class="social-icon" src="images/ima/1/insta.png" alt="Instagram">
                    </li>
                </a>
            </ul>
        </div>

        <!-- Column 2 -->
        <div class="footer-col-2">
            <img src="images/ima/1/r1.png">
            <p class="footer-p">Paving Paths for Brighter Futures</p>
        </div>

        <!-- Column 3 -->
        <div class="footer-col-3">
            <h3 class="footer-h3">Contact Us</h3>
            <p class="footer-p" style="font-weight: lighter;">greenpath@gmail.com</p><br>
            <p class="footer-p" style="font-weight: lighter;">(+63) 968-459-3721</p>
        </div>
        </div>
        <hr class="footer-hr">
        <p class="Copyright" style="font-weight: bold;">Copyright 2022</p>
    </div>
</div>
</body>
</html>