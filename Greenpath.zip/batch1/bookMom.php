
<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mountain Bike Booking</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" media="screen" href="book.php">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <!-- Bootstrap Font Icon CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

        <!-- Include Pikaday CSS from CDN -->
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/pikaday/1.8.0/css/pikaday.min.css">
        <!-- Include Moment.js (required by Pikaday) from CDN -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>



</head>
<body>
    <!-- Navbar-->
    <div class="header">
    <div class="container1">
        <div class="logo-nav-container">
            <div class="navbar">
                <nav>  
                    <ul id="MenuItems" class="center-menu">
                        <li class="pages"><a href="guidelines.php" style="color: white">Guidelines</a></li>
                        <li class="pages"><a href="catalog.php" style="border-bottom: 2px solid white; color: white">Booking</a></li>
                        <li class="pages"><a href="repair.php" style="color: white">Maintenance</a></li>
                        <li class="logo-item"><a href="index.php"><img src="images/ima/1/r1.png" alt="Logo"></a></li> 
                        <li class="pages"><a href="trans.php" style="color: white">Transaction</a></li>
                        <li class="pages"><a href="about.php" style="color: white">About Us</a></li>
                        <li class="pages"><a href="signin.php" style="color: white">Log In</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>
<!-- navbar endd -->


<div class="container">
<!-- C1 -->

<h2 style="color: black">Rent A Bike</h2>
<br>
<div class="row">
<!-- bike cards row 1 -->
<div class="col-sm-7 col-12">
<div class="row bikeContainer">
  <div class="col-xl-4 col-sm-6 col-12"> 
    <div class="card bike-card">
      <div class="card-content">
        <div class="card-body">
          <div class="media d-flex">
            <div class="align-self-center">
            <!-- <div> Icons made by <a href="https://www.freepik.com" title="Freepik"> Freepik </a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com'</a></div> -->

              <img class="icons float-left" src="img/basketBike.png" alt="Mom's Bike">
              
            </div>
            <div class="media-body text-right">
              <h4>08105</h4>
              <button class="pickBtn" data-bike-number="08105" >Pick</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-xl-4 col-sm-6 col-12">
    <div class="card bike-card">
      <div class="card-content">
        <div class="card-body">
          <div class="media d-flex">
            <div class="align-self-center">
                <!-- <div> Icons made by <a href="https://www.freepik.com" title="Freepik"> Freepik </a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com'</a></div> -->

                <img class="icons float-left" src="img/basketBike.png" alt="Mom's Bike">

            </div>
            <div class="media-body  text-right">
              <h4>08106</h4>
              <button class="pickBtn"data-bike-number="08106" >Pick</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-xl-4 col-sm-6 col-12">
    <div class="card bike-card">
      <div class="card-content">
        <div class="card-body">
          <div class="media d-flex">
            <div class="align-self-center">
                <!-- <div> Icons made by <a href="https://www.freepik.com" title="Freepik"> Freepik </a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com'</a></div> -->
                <img class="icons float-left" src="img/basketBike.png" alt="Mom's Bike"> 

            </div>
            <div class="media-body text-right">
              <h4>08107</h4>
              <button class="pickBtn" data-bike-number="08107" >Pick</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- bike cards row 1 END -->

<!-- bike cards row 2 -->
<div class="row bikeContainer">
  <div class="col-xl-4 col-sm-6 col-12"> 
    <div class="card bike-card">
      <div class="card-content">
        <div class="card-body">
          <div class="media d-flex">
            <div class="align-self-center">
                <!-- <div> Icons made by <a href="https://www.freepik.com" title="Freepik"> Freepik </a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com'</a></div> -->
                <img class="icons float-left" src="img/basketBike.png" alt="Mom's Bike"> 
            </div>
            <div class="media-body text-right">
              <h4>08108</h4>
              <button class="pickBtn" data-bike-number="08108" >Pick</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-xl-4 col-sm-6 col-12">
    <div class="card bike-card">
      <div class="card-content">
        <div class="card-body">
          <div class="media d-flex">
            <div class="align-self-center">
              <!-- <div> Icons made by <a href="https://www.freepik.com" title="Freepik"> Freepik </a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com'</a></div> -->
              <img class="icons float-left" src="img/basketBike.png" alt="Mom's Bike"> 
            </div>
            <div class="media-body  text-right">
              <h4>08109</h4>
              <button class="pickBtn" data-bike-number="08109" >Pick</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-xl-4 col-sm-6 col-12">
    <div class="card bike-card">
      <div class="card-content">
        <div class="card-body">
          <div class="media d-flex">
            <div class="align-self-center">
              <!-- <div> Icons made by <a href="https://www.freepik.com" title="Freepik"> Freepik </a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com'</a></div> -->
                <img class="icons float-left" src="img/basketBike.png" alt="Mom's Bike"> 
            </div>
            <div class="media-body text-right">
              <h4>08110</h4>
              <button class="pickBtn" data-bike-number="08110" >Pick</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- bike cards row 2 END -->

<!-- bike cards row 3 -->
<div class="row bikeContainer">
  <div class="col-xl-4 col-sm-6 col-12"> 
    <div class="card bike-card">
      <div class="card-content">
        <div class="card-body">
          <div class="media d-flex">
            <div class="align-self-center">
                <!-- <div> Icons made by <a href="https://www.freepik.com" title="Freepik"> Freepik </a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com'</a></div> -->
                <img class="icons float-left" src="img/basketBike.png" alt="Mom's Bike"> 
            </div>
            <div class="media-body text-right">
              <h4>08111</h4>
              <button class="pickBtn" data-bike-number="08111" >Pick</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-xl-4 col-sm-6 col-12">
    <div class="card bike-card">
      <div class="card-content">
        <div class="card-body">
          <div class="media d-flex">
            <div class="align-self-center">
              <!-- <div> Icons made by <a href="https://www.freepik.com" title="Freepik"> Freepik </a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com'</a></div> -->
              <img class="icons float-left" src="img/basketBike.png" alt="Mom's Bike"> 
            </div>
            <div class="media-body  text-right">
              <h4>08112</h4>
              <button class="pickBtn" data-bike-number="08112" >Pick</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-xl-4 col-sm-6 col-12">
    <div class="card bike-card">
      <div class="card-content">
        <div class="card-body">
          <div class="media d-flex">
            <div class="align-self-center">
              <!-- <div> Icons made by <a href="https://www.freepik.com" title="Freepik"> Freepik </a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com'</a></div> -->
                <img class="icons float-left" src="img/basketBike.png" alt="Mom's Bike"> 
            </div>
            <div class="media-body text-right">
              <h4>08113</h4>
              <button class="pickBtn" data-bike-number="08113" >Pick</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- bike card rows end  -->
</div> <!-- bike cards column END -->

<!-- C1 END -->
<!-- C2 -->  


<div class="col-12  col-sm-5">
    
        <div class="form"> 
            <!-- Repair request Form -->
            <form action=" " method="POST" >

                <br>

                <div class="single-row">       
                    <!--readonly input for the user's selected bike number  -->
                    <input type="text" id="bikeNumberInput" name="bikeNumberInput" value="" placeholder="Pick a Bike to Record" style="color: #808080;"readonly/>
                    <!-- Input field for Student Number, required -->
                    <div class="single-column" id="column1">
                        <input type="text" id="studNum"name="studNo" placeholder="ID Number" required readonly>
                        <div class="invalid-feedback">Please fill out this field.</div>
                    </div>
                    <!-- Input field for Date, required -->
                    <div class="single-column" id="column1">
                        <input type="text" id="postDate" name="postDate" class="datepicker" placeholder="Pick a Date" required readonly>
                        <div class="invalid-feedback">Please fill out this field.</div>
                    </div>

                      <!-- Dropdown for Payment Option, required -->
                      <div class="single-column">
                          <button type="button" name="payment" class="btn paymentArrow dropdown-toggle float-right custom-dropdown" id="PaymentDropDown" onclick="dropdownSelect()" data-toggle="dropdown" data-toggle="tooltip" data-placement="top" title="Choose when to pay your booking charges" aria-haspopup="true" aria-expanded="false" data-validation="required" disabled>
                              Payment Option
                          </button>
                          <input type="hidden" name="payment" id="PaymentInputValue" required readonly>
                          <div class="dropdown-menu">
                              <div class="dropdown-item" onclick="updatePlaceValue('Before Booking', 'PaymentInputValue')">Pay Before Booking</div>
                              <div class="dropdown-item" onclick="updatePlaceValue('After Booking', 'PaymentInputValue')">Pay After Booking</div>
                          </div> <!-- dropdown menu div -->
                      </div>

                </div>
                
            
                <!-- Submit button -->
                <input type="submit" value="SUBMIT" id="btn" class="submitBtn"  onclick="onSubmitButtonClick()"  />
                <br><br>
                <span id="error-msg" style="color: red;"></span>
            </form>
        </div> 
    </div>
</div> 
<!-- container end -->
</div> <!-- col form end  -->
</div> <!-- row form and bikes end  -->



<!-- Modal -->
<div class="modal fade" id="popupModal" tabindex="-1" aria-labelledby="popupModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="popupModalLabel">Sign up or Log in</h5>
        <button type="button" class="custom-close-btn" data-bs-dismiss="modal" aria-label="Close">X</button>
      </div>
      <div class="modal-body">
        <p>You must sign in or create an account to rent a bike</p>
      </div>
    </div>
  </div>
</div>



<!--- Footer Section -->
<div class="footer">
    <div class="footer-container">
        <div class="footer-row">

        <!-- Column 1 -->
        <div class="footer-col-1">
            <h3 class="footer-h3">Follow Us</h3>
            <ul class="footer-ul">
                <a href="https://www.facebook.com/profile.php?id=61552094544554&mibextid=ZbWKwL">
                    <li>
                        <img class="social-icon" src="images/ima/1/facebook.png" alt="Facebook">
                    </li>
                </a>
                <a href="https://instagram.com/greenpath_rental?igshid=MzMyNGUyNmU2YQ==">
                    <li>
                        <img class="social-icon" src="images/ima/1/insta.png" alt="Instagram">
                    </li>
                </a>
            </ul>
        </div>

        <!-- Column 2 -->
        <div class="footer-col-2">
            <img src="images/ima/1/r1.png">
            <p class="footer-p">Paving Paths for Brighter Futures</p>
        </div>

        <!-- Column 3 -->
        <div class="footer-col-3">
            <h3 class="footer-h3">Contact Us</h3>
            <p class="footer-p" style="font-weight: lighter;">greenpath@gmail.com</p><br>
            <p class="footer-p" style="font-weight: lighter;">(+63) 968-459-3721</p>
        </div>
        </div>
        <hr class="footer-hr">
        <p class="Copyright" style="font-weight: bold;">Copyright 2022</p>
    </div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>
<!-- Bootstrap Datepicker JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<!-- Include Pikaday JavaScript from CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/pikaday/1.8.0/pikaday.min.js"></script>
<!-- Include Moment.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>

<!-- Include DatePair CSS and JavaScript -->
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap-daterangepicker@3.0.5/daterangepicker.css" />
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/bootstrap-daterangepicker@3.0.5/daterangepicker.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
 
   // Function to show the modal
   function showModal() {
    $('#popupModal').modal('show');
  }

  // Show the modal after 3 seconds and then every 3 seconds in a loop
  setTimeout(function() {
    showModal();
    setInterval(showModal, 3000);
  }, 3000);
</script>
</body>
</html>