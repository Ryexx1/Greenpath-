function logout() {
    var confirmLogout = confirm("Are you sure you want to log out?");
    if (confirmLogout) {
        // If the user clicks "OK" on the confirmation dialog
        window.location.href = "../batch1/signin.php";
    } else {
        //if cancel do nothing
    }
}