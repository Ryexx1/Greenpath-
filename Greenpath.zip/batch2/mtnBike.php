<?php header("Content-type: text/css"); ?>
/* Reset styles for all elements */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Trebuchet MS, sans-serif;

}


/* NAVBAR */
/* Styles for the logo image */
.logo-item img {
    width: 90px;
    height: auto;
    margin-left: 150px;
    margin-right: 150px;
}

/* Center the navigation menu items */
.center-menu {
    list-style-type: none;
    display: flex;
    justify-content: center;
    align-items: center;
}

.center-menu:hover {
    color: white;
}

.pages {
    margin-right: 25px; 
    margin-left: 25px; 
    font-size: 16px;
    font-family: Trebuchet MS, sans-serif;
}

.pages:hover{
    background: rgba(255, 255, 255, 0.2);
    padding: 15px 0 15px 0;
}

/* Styles for anchor links */
a {
    text-decoration: none;
    color: #000000;
    font-family: Trebuchet MS, sans-serif;
    color: white;
    padding: 0 5px 0 5px;
}

.container1 {
    max-width: 1300px;
    margin: auto;
    height: 95px;
}

.header{
    background-color: #062644;
    margin-bottom: 20px;
}

.container {
    max-width: 1300px;
    margin: auto;
}




/*C1 */
.bikeContainer{
    max-width: 800px;
    margin: auto;
}
/**styling for icon and cards */
i{
    color: #062644;
    font-size: 60px;
    margin-right: 40px;
    margin-left: 10px;
}
.icons{
    color: #062644; 
    font-size: 50px;
    margin-right: 20px;
    
}
.pickBtn{
    font-size: 15px;
    color: #000; 
    background-color: #fff; 
    padding: 5px 10px 5px 10px;
    border: 1px solid #000;
    font-family: Trebuchet MS, sans-serif;
    
}

.bike-card{
    /* Set initial styles */
  transition: transform 0.3s, box-shadow 0.3s;
  border: 2px solid #ccc;
  margin: 10px;
  border-radius: 0px;
}
.bike-card:hover{
    /* Apply lifting effect */
  transform: translateY(-5px);
  /* Apply box shadow for a shadow effect */
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);

}
.pickBtn:hover{
    font-size: 15px; 
    color: #fff; 
    background-color: #062644; 
    border: 1px solid #CCC; 
}
.media-body{
    text-align: right;
}

.media-body h4{
    padding-top: 15px;
    font-weight: bold;
}
h2{
    text-align: center; 
    font-family: Trebuchet MS, sans-serif;
}
.bike-card.lifted {
  transform: translateY(-5px);
  box-shadow: 0 4px 8px rgba(0, 128, 0, 0.5);
}

.pickBtn.active {
  background-color: #F18A06;
  color: #062644;
}
.dark-placeholder::placeholder {
    color: #555; /* Darken color as per your preference */
    opacity: 0.8; /* Adjust opacity to your liking */
}




/*c2*/
/*form styles */
/* Styling for the maintenance form container */

.container form{
    justify-contents: center; 
    text-align: center; 
    overflow: hidden;
    align-items: center;
}

.form{ 
    max-width: 100%;
    max-height: 1000px;
    padding: 30px;
    text-align: center;
    background: white;
} 



/* Styling for form inputs */
.form input{ 
    font-family: Trebuchet MS, sans-serif;
    outline: 1;
    width: 85%; 
    border: 2px solid #ccc; 
    margin: 0 0 15px; 
    padding: 15px; 
    box-sizing: border-box; 
    font-size: 14px; 
    } 
#bikeNumberInput::placeholder {
      color: #B0B0B0; 
}
#bikeNumberInput{
    color: #B0B0B0;
}
#btn{
    color: #fff; 
    background-color: #F18A06;
    border: 2px solid #ccc;
}
.form #PaymentDropDown{
    font-family: Trebuchet MS, sans-serif;
    outline: 1;
    width: 85%; 
    border-radius: 0px;
    border: 2px solid #ccc; 
    margin: 0 0 15px; 
    padding: 15px; 
    box-sizing: border-box; 
    font-size: 14px; 
    text-align: left;
    color: #7D7C7C;
}
.submitBtn{
    font-weight: bold;
}



/*C3 */
.modal-body {
    width: 900px;
    margin: auto;
    
    height: 380px;
    background-image: url('img/ticket.png');
    background-size: cover;
    background-position: center;
    text-align: center;
    }

.modal-content {
    font-family: 'Times New Roman', sans-serif;
    border-radius: 0; /* Set border-radius to 0 for sharp edges */
    color: #000;
    margin: auto;
   
}

.idNum{
    font-weight: bold;
    text-align: left; 
    margin-top: 14%; 
    font-size: 30px;
}
.pay{
    font-weight: bold;
    text-align: center;
    margin-top: 29%;
    margin-left: 30%; 
    font-size: 15px

}


.ticketDetails .bookno{
    font-weight: bold; 
    font-size: 30px;
    letter-spacing: 0.5px; 
    margin-top: 30%;
    margin-left: 16%;
}
.ticketDetails .bookDate{
      font-weight: bold;
      margin-top: 30px;
      font-size: 25px;
      margin-left: 16%;

}
    
.ticketDetails .bikeno{
    font-weight: bold; 
    text-align: right; 
    margin-top: 6%;
    margin-right: 5px; 
    white-space: pre;
}


.sideNote{
    text-align: center;     
}

        @keyframes blink {
            0% {
                opacity: 1;
            }
            50% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }

        .blinking-text {
            animation: blink 2s infinite; /* Change the duration as needed */
            color: #333;
            font-size: 12px;
            margin-top: 10px;
            margin-left: 10%;
            
        }





/* Footer styles */
/* Styling for the footer container */
.footer {
    background: #062644;
    color: white;
    font-size: 16px;
    text-align: center;
    padding: 21px 0;
    margin-top: 50px;
}

/* Styling for paragraphs within the footer */
.footer-p {
    color: white;
    font-weight: bold;
}

/* Styling for footer heading */
.footer-h3 {
    color: white;
    padding-top: 40px;
    margin-bottom: 20px;
    font-size: 20px;
    font-weight: bold;
}

/* Styling for the footer container */
.footer-container {
    margin: auto;
    max-width: 1000px;
    padding-left: 5px;
    padding-right: 5px;
}

/* Styling for the row in the footer */
.footer-row {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: space-around;
}

/* Styling for the first column in the footer */
.footer-col-1 {
    min-height: 200px;
    margin-bottom: 20px;
    font-family: Trebuchet MS, sans-serif;
    flex-basis: 12%;
    text-align: center;
}

/* Styling for social media icons */
.social-icon {
    width: 90px;
    height: 90px;
}

/* Styling for the second column in the footer */
.footer-col-2 {
    padding-left: 5px;
    min-height: 200px;
    margin-bottom: 20px;
    flex: 1;
    font-family: Trebuchet MS, sans-serif;
    text-align: center;
}

/* Styling for images in the second column of the footer */
.footer-col-2 img {
    width: 180px;
    margin-bottom: 20px;
}

/* Styling for the third column in the footer */
.footer-col-3 {
    min-height: 200px;
    margin-bottom: 10px;
    font-family: Trebuchet MS, sans-serif;
    flex-basis: 12%;
    text-align: center;
}

/* Styling for the footer unordered list */
.footer-ul {
    list-style-type: none;
    display: flex;
    list-style: none;
    padding: 0;
}

/* Styling for list items in the footer unordered list */
.footer-ul li {
    margin-right: 1px;
}

/* Styling for the horizontal rule in the footer */
.footer-hr {
    border: none;
    background: #b5b5b5;
    height: 1px;
    margin: 20px 0;
}

/* Styling for the copyright text in the footer */
.Copyright {
    font-size: 12px;
    text-align: center;
    font-family: Trebuchet MS, sans-serif;
}
