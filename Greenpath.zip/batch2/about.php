<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>About Us</title>
    <link rel="stylesheet" type="text/css" media="screen" href="us.php">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>  
<body>





<!-- Navbar-->
<div class="header">
    <div class="container">
        <div class="logo-nav-container">
            <div class="navbar">
                <nav>  
                    <ul id="MenuItems" class="center-menu">
                        <li class="pages"><a href="guidelines.php">Guidelines</a></li>
                        <li class="pages"><a href="bookingCatalog.php">Booking</a></li>
                        <li class="pages"><a href="repair.php">Maintenance</a></li>
                        <li class="logo-item"><a href="index.php"><img src="images/ima/1/r1.png" alt="Logo"></a></li>
                        <li class="pages"><a href="transaction.php">Transaction</a></li>
                        <li class="pages"><a href="about.php" style="border-bottom: 2px solid white">About Us</a></li>
                        <li class="pages"><a href="settings.php">Settings</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>



<!-- Image, text (C1) -->
<div class="image-section">
    <div class="container">
        <div class="image-content">
            <div class="text">
                <h1>1. INTRODUCTION</h1>
                <p id="pedal">Welcome to GreenPath Cycles, a cutting-edge bike rental service 
                    dedicated to providing convenient and eco-friendly transportation solutions 
                    for the university members.</p>
            </div>
            <div class="image">
                <img src="images/ima/6/11.png" alt="Your Image">
            </div>
        </div>
    </div>
</div>

<div class="image-section">
    <div class="container">
        <div class="image-content">
            <div class="text2">
                <h1>2. VISION AND MISSION</h1>
                <p id="pedal">Envisioning a campus where every journey is an opportunity to contribute to 
                    a healthier lifestyle and a more sustainable future.</p>
                <p id="pedal">Our mission is to promote sustainable and healthy 
                    commuting options within the campus community. We strive to make biking accessible, enjoyable, 
                    and a key component of a greener university environment.</p>
            </div>
            <div class="image">
                <img src="images/ima/6/2.png" alt="Your Image">
            </div>
        </div>
    </div>
</div>

<div class="image-section">
    <div class="container">
        <div class="image-content">
            <div class="text">
                <h1>3. CORE VALUES</h1>
                <p id="pedal">Sustainability: We are committed to reducing the carbon footprint on campus by promoting 
                    eco-friendly commuting alternatives.</p>
                <p id="pedal">Accessibility: Ensuring that our bike rental system is accessible to all university members, fostering inclusivity and community engagement.</p>
                <p id="pedal">Innovation: Embracing technology and innovation to enhance the user experience and stay at the forefront of campus transportation solutions.</p>
            </div>
            <div class="image">
                <img src="images/ima/6/13.png" alt="Your Image">
            </div>
        </div>
    </div>
</div>

<div class="image-section">
    <div class="container">
        <div class="image-content">
            <div class="text2">
                <h1>4. ADDITIONAL INFORMATION</h1>
                <p id="links"><a href="terms.html" style="color: black">Terms and Conditions</a></p>
                <p id="links"><a href="privacy.html" style="color: black">Privacy Policy</a></p>
                <p id="links"><a href="cancel.html" style="color: black">Cancellation Policy</a></p>
            </div>
            <div class="image">
                <img src="images/ima/6/14.png" alt="Your Image">
            </div>
        </div>
    </div>
</div>





<!--- Footer Section -->
<div class="footer">
    <div class="footer-container">
        <div class="footer-row">

        <!-- Column 1 -->
        <div class="footer-col-1">
            <h3 class="footer-h3">Follow Us</h3>
            <ul class="footer-ul">
                <a href="https://www.facebook.com/profile.php?id=61552094544554&mibextid=ZbWKwL">
                    <li>
                        <img class="social-icon" src="images/ima/1/facebook.png" alt="Facebook">
                    </li>
                </a>
                <a href="https://instagram.com/greenpath_rental?igshid=MzMyNGUyNmU2YQ==">
                    <li>
                        <img class="social-icon" src="images/ima/1/insta.png" alt="Instagram">
                    </li>
                </a>
            </ul>
        </div>

        <!-- Column 2 -->
        <div class="footer-col-2">
            <img src="images/ima/1/r1.png">
            <p class="footer-p">Paving Paths for Brighter Futures</p>
        </div>

        <!-- Column 3 -->
        <div class="footer-col-3">
            <h3 class="footer-h3">Contact Us</h3>
            <p class="footer-p" style="font-weight: lighter;">greenpath@gmail.com</p><br>
            <p class="footer-p" style="font-weight: lighter;">(+63) 968-459-3721</p>
        </div>
        </div>
        <hr class="footer-hr">
        <p class="Copyright" style="font-weight: bold;">Copyright 2022</p>
    </div>
</div>
</body>
</html>