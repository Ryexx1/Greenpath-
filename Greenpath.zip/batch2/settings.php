<?php 
$success = 0;
$invalid = 0;
$user = 0;
$matchErr=0;
function startsWith($haystack, $prefixes) {
  foreach ($prefixes as $prefix) {
      $length = strlen($prefix);
      if ($length > 0 && substr($haystack, 0, $length) === $prefix) {
          return true;
      }
  }
  return false;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include('includes/dbh.inc.php'); // Assuming your connection file is named "dbh.inc.php"
    $currentPass = $_POST['currentPass'];
    $newPass = $_POST['newPass'];
    $studno = $_POST['studno'];
    $confirmPass = $_POST['confirmPass'];
    // Check if the email ends with "@iskwela.psau.edu.ph"

    $sql = "SELECT pass FROM account WHERE id_no='$studno'";
    $result = mysqli_query($conn, $sql);

    if($confirmPass != $newPass){
        $matchErr = 1;
    }else{
            if ($result) {
                $row = mysqli_fetch_assoc($result);
                if ($row) {
                    // User with the provided email exists
                    $hashedPassword = $row['pass'];
                    
                    // Check if the provided password matches the stored hashed password
                    if (password_verify($currentPass, $hashedPassword)) {
                        

                        // Generate a new hashed password for the new password
                        $newHashedPassword = password_hash($newPass, PASSWORD_DEFAULT);

                        // Update the password in the "account" table
                        $updateQuery = "UPDATE account SET pass = '$newHashedPassword' WHERE id_no = '$studno'";
                        $updateResult = mysqli_query($conn, $updateQuery);

                        if ($updateResult) {
                            // Password updated successfully
                            $success = 1; // password success
                        } else {
                            // Handle the case where the password update fails
                            echo '<script>document.getElementById("error-msg").innerHTML = "Password update failed. Please try again later"; </script>';
                        }
                    } else {
                        $invalid = 1; // Incorrect password
                    }
                } else {
                    $user = 1; // User does not exist
                }
            } else {
                // Handle other error cases
                echo '<script>document.getElementById("error-msg").innerHTML = "Incorrect Password"; </script>';
            }
    }
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings</title>
    <!-- bootstrap css -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <!-- css -->
    <link rel="stylesheet" type="text/css" media="screen" href="set.php">
    
    <!-- other links -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    
    <!-- Bootstrap Font Icon CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

</head>
<body>
       <!-- Navbar-->
       <div class="header">
    <div class="container1">
        <div class="logo-nav-container">
            <div class="navbar">
                <nav>  
                    <ul id="MenuItems" class="center-menu">
                        <li class="pages"><a href="guidelines.php" style="color: white">Guidelines</a></li>
                        <li class="pages"><a href="catalog.php" style="color: white">Booking</a></li>
                        <li class="pages"><a href="repair.php" style="color: white">Maintenance</a></li>
                        <li class="logo-item"><a href="index.php"><img src="images/ima/1/r1.png" alt="Logo"></a></li> 
                        <li class="pages"><a href="transaction.php" style="color: white">Transaction</a></li>
                        <li class="pages"><a href="about.php" style="color: white">About Us</a></li>
                        <li class="pages"><a href="settings.php" style="border-bottom: 2px solid white; color: white">Settings</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>
<!-- navbar endd -->

<div class="container settingsContent">
    <div class="row">
        <!-- c1 -->
        <div class="col-12 col-xl-3  col-sm-3" id="sideNav">
            <h5 class="menuTitle">Settings</h5>
        
            <a href="settings.php"><h6 class="menu" style=" background-color: #062644; color: #fff;">Change Password</h6></a>
            <a href="deAcc.php"><h6 class="menu">Deactivate Account</h6></a>
            <a href="deleteAcc.php"><h6 class="menu" >Delete Account</h6></a>
            <a href="#" onclick="logout()"><h6 class="menu">Log Out</h6></a>
        </div>
        <!-- c1 end -->
        <!-- c2 -->
        <div class="col-12 col-xl-5 col-sm-5">
            <p class="menuContentTitle slideContents">Change Password</p>
            <div class="form"> 
                <!-- Repair request Form -->
                <form action=" " method="POST" >

                    
                        <!-- input for the user's current password  -->
                        <input type="text" id="currentPass" name="currentPass" value="" placeholder="Current Password" required/>
                        <div class="invalid-feedback">Please fill out this field.</div>
                        
                        <!-- input for the user's new password  -->
                        <input type="password" id="newPass" name="newPass" value="" placeholder="New Password" required/>
                        <div class="invalid-feedback">Please fill out this field.</div>
                        
                        <!-- confirm user password -->
                        <input type="password" id="confirmPass" name="confirmPass" value="" placeholder="Confirm Password" required/>
                        <div class="invalid-feedback">Please fill out this field.</div>

                        <!-- confirm user password -->
                        <input type="text" id="studno" name="studno" value="" placeholder="Student Number" required/>
                        <div class="invalid-feedback">Please fill out this field.</div>

                    
                    
                
                    <!-- Submit button -->
                    <input type="submit" value="SUBMIT" id="btn"  onclick="onSubmit()"  />
                    <br>
                    <span id="error-msg" style="color: red;"></span>
                </form>
            </div>         
        </div>
        <!-- c2 end  -->
        <!-- C3 -->
        <div class="col-xl-3 col-sm-3 col-12" id="infoss">
                <img src="img/re.png" alt="Additional Info Image">
                <p class="menu2" style="font-size: 14px;">A gentle reminder to approach account settings 
                with mindfulness – every choice shapes your digital realm for a more secure and enjoyable interaction.</p>
            </div>
            <!-- C3 end -->
    </div>
</div>
<?php
if($success){
    echo "<script> alert('Password changed. Please take note of your new password');
    window.location.href = '../batch1/signin.php';
    </script>"; 
}
if($invalid){
    echo "<script> document.getElementById('error-msg').innerHTML = 'Incorrect Password';
                   document.getElementById('error-msg').color = 'red';
        </script>"; 
}
if($user){
    echo "<script> document.getElementById('error-msg').innerHTML = 'User Does not Exist';
    document.getElementById('error-msg').color = 'red';
  </script>"; 
}
if($matchErr){
    echo "<script> document.getElementById('error-msg').innerHTML = 'Passwords doesn\'t match';
    document.getElementById('error-msg').color = 'red';
  </script>";
}
?>

<!--- Footer Section -->
<div class="footer">
    <div class="footer-container">
        <div class="footer-row">

        <!-- Column 1 -->
        <div class="footer-col-1">
            <h3 class="footer-h3">Follow Us</h3>
            <ul class="footer-ul">
                <a href="https://www.facebook.com/profile.php?id=61552094544554&mibextid=ZbWKwL">
                    <li>
                        <img class="social-icon" src="images/ima/1/facebook.png" alt="Facebook">
                    </li>
                </a>
                <a href="https://instagram.com/greenpath_rental?igshid=MzMyNGUyNmU2YQ==">
                    <li>
                        <img class="social-icon" src="images/ima/1/insta.png" alt="Instagram">
                    </li>
                </a>
            </ul>
        </div>

        <!-- Column 2 -->
        <div class="footer-col-2">
            <img src="images/ima/1/r1.png">
            <p class="footer-p">Paving Paths for Brighter Futures</p>
        </div>

        <!-- Column 3 -->
        <div class="footer-col-3">
            <h3 class="footer-h3">Contact Us</h3>
            <p class="footer-p" style="font-weight: lighter;">greenpath@gmail.com</p><br>
            <p class="footer-p" style="font-weight: lighter;">(+63) 968-459-3721</p>
        </div>
        </div>
        <hr class="footer-hr">
        <p class="Copyright" style="font-weight: bold;">Copyright 2022</p>
    </div>
</div>
<script src="js/logout.js"></script>
</body>
</html>