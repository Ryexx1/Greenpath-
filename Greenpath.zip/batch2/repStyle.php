<?php header("Content-type: text/css"); ?>
/* Reset styles for all elements */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Trebuchet MS, sans-serif;

}


/* NAVBAR */
/* Styles for the logo image */
.logo-item img {
    width: 90px;
    height: auto;
    margin-left: 150px;
    margin-right: 150px;
}

/* Center the navigation menu items */
.center-menu {
    list-style-type: none;
    display: flex;
    justify-content: center;
    align-items: center;
}

.center-menu:hover {
    color: white;
}

.pages {
    margin-right: 25px; 
    margin-left: 25px; 
    font-size: 16px;
    font-family: Trebuchet MS, sans-serif;
}

.pages:hover{
    background: rgba(255, 255, 255, 0.2);
    padding: 15px 0 15px 0;
}

/* Styles for anchor links */
a {
    text-decoration: none;
    color: #000000;
    font-family: Trebuchet MS, sans-serif;
    color: white;
    padding: 0 5px 0 5px;
}

.container1 {
    max-width: 1300px;
    margin: auto;
    height: 95px;
}

.header{
    background-color: #062644;
    margin-bottom: 20px;
}

.container {
    max-width: 1300px;
    margin: auto;
}




/* C1*/

/* Style for the new image section */
.image-section {
    background-color: white;
    position: relative; /* Add relative positioning to the container */
}

/* Style for the text and button */
.text-and-button {
    position: absolute; 
    top: 50%; 
    left: 0; 
    transform: translateY(-50%); 
    padding: 20px;
    text-align: left;
    width: 50%; 
    box-sizing: border-box; 
    font-family: Trebuchet MS, sans-serif;
}

.text-and-button h1 {
    font-size: 35px;
    font-weight: bold;
    color: white;
    margin-bottom: 40px;
    margin-left: 150px;
    font-family: Trebuchet MS, sans-serif;
}

.text-and-button p {
    font-size: 16px;
    color: white;
    margin-bottom: 10px;
    margin-left: 150px;
    font-family: Trebuchet MS, sans-serif;
}

.btn {
    display: inline-block;
    padding: 10px 50px;
    color: #333;
    text-decoration: none;
    border: 2px solid #333;
    border-radius: 15px;
    font-weight: bold;
    margin-top: 20px;
    align-items: center;
    font-size: 25px;
    
}
/* Add the new styles for positioning the carousel caption */
.carousel-caption {
    text-align: left;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    margin: 50px;
    color: #333; /* Set text color */
}


/* Style for the image on the right side */
.image img {
    max-width: 90%;
    border-radius: 50px;

}

/* Style for the image on the center */
.image {
    flex: 1; /* Let the image occupy available space */
    text-align: center; /* Center the image horizontally */
    justify-content: center; 
    max-height: 100%;

}


a:hover{
    text-decoration: none;
    color: #000000;
    font-family: Trebuchet MS, sans-serif;
}

.btn-row{
    text-align: center;

}
.carousel{
    max-width: 70%;
    height: auto;
    border-radius: 50px;
    text-align: center; 
    overflow: hidden;
   
}
.carousel-inner{
    width: 100%;
    height: 60%; 
    border-radius: 50px;
    height: 60%;
    overflow: hidden;
}
#carouselBktBike .carousel-indicators li {
    background-color: black;
  }
.btn-container{
    align-items: center; 
    justify-contents: center; 
    text-align: center;
}
.carousel-item img{
    height: 600px;
}
#btn{
    color: #fff; 
    background-color: #F18A06;
    border: 2px solid #ccc;
    font-weight: bold;
    text-align: center;
}

.canceled-card{
    color: #000; 
    background-color: #ccc; 
    font-weigh: bold;
}







/*C2*/
/*form styles */
/* Styling for the maintenance form container */

.container form{
    justify-contents: center; 
    text-align: center; 
    overflow: hidden;
    align-items: center;
}

.form{ 
    max-width: 100%;
    max-height: 1000px;
    padding: 30px;
    text-align: center;
    background: white;
} 



/* Styling for form inputs */
.form input{ 
    font-family: Trebuchet MS, sans-serif;
    outline: 1;
    width: 85%; 
    border-radius: 0px;
    border: 2px solid #ccc; 
    margin: 0 0 15px; 
    padding: 15px; 
    box-sizing: border-box; 
    font-size: 14px; 
    text-align: left;
    color: #7D7C7C;
    } 

.form #locationDropDown{
    font-family: Trebuchet MS, sans-serif;
    outline: 1;
    width: 85%; 
    border-radius: 0px;
    border: 2px solid #ccc; 
    margin: 0 0 15px; 
    padding: 15px; 
    box-sizing: border-box; 
    font-size: 14px; 
    text-align: left;
    color: #7D7C7C;
}
.form #placeInputRepairType, #priorityDropDown{
    font-family: Trebuchet MS, sans-serif;
    outline: 1;
    width: 85%; 
    border-radius: 0px;
    border: 2px solid #ccc; 
    margin: 0 0 15px; 
    padding: 15px; 
    box-sizing: border-box; 
    font-size: 14px; 
    text-align: left;
    color: #7D7C7C;
}

#priorityDropDown, #typeOfRepDropDown, #locationDropDown:hover{

    font-family: Trebuchet MS, sans-serif;
    outline: 1;
    width: 85%; 
    border-radius: 0px;
    border: 2px solid #ccc; 
    margin: 0 0 15px; 
    padding: 15px; 
    box-sizing: border-box; 
    font-size: 14px; 
    text-align: left;
    color: #7D7C7C;
}

span#error-msg{
    color: red; 
    font-size: 15px;
}

.form #comment{
    font-family: Trebuchet MS, sans-serif;
    outline: 1;
    width: 85%; 
    border-radius: 0px;
    border: 2px solid #ccc; 
    margin: 0 0 15px; 
    padding: 15px; 
    box-sizing: border-box; 
    font-size: 14px; 
    text-align: left;
    color: #7D7C7C;
}

.dropdown-item {
        font-size: 16px; /* Adjust the font size as needed */
        line-height: 2; /* Adjust the spacing between options as needed */
        font-family: Trebuchet MS, sans-serif;
    }
.dropdown-item:hover{
    color: #000; 
    background-color: #7D7C7C;
}






/* Footer styles */
/* Styling for the footer container */
.footer {
    background: #062644;
    color: white;
    font-size: 16px;
    text-align: center;
    padding: 21px 0;
    margin-top: 50px;
}

/* Styling for paragraphs within the footer */
.footer-p {
    color: white;
    font-weight: bold;
}

/* Styling for footer heading */
.footer-h3 {
    color: white;
    padding-top: 40px;
    margin-bottom: 20px;
    font-size: 20px;
    font-weight: bold;
}

/* Styling for the footer container */
.footer-container {
    margin: auto;
    max-width: 1000px;
    padding-left: 5px;
    padding-right: 5px;
}

/* Styling for the row in the footer */
.footer-row {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: space-around;
}

/* Styling for the first column in the footer */
.footer-col-1 {
    min-height: 200px;
    margin-bottom: 20px;
    font-family: Trebuchet MS, sans-serif;
    flex-basis: 12%;
    text-align: center;
}

/* Styling for social media icons */
.social-icon {
    width: 90px;
    height: 90px;
}

/* Styling for the second column in the footer */
.footer-col-2 {
    padding-left: 5px;
    min-height: 200px;
    margin-bottom: 20px;
    flex: 1;
    font-family: Trebuchet MS, sans-serif;
    text-align: center;
}

/* Styling for images in the second column of the footer */
.footer-col-2 img {
    width: 180px;
    margin-bottom: 20px;
}

/* Styling for the third column in the footer */
.footer-col-3 {
    min-height: 200px;
    margin-bottom: 10px;
    font-family: Trebuchet MS, sans-serif;
    flex-basis: 12%;
    text-align: center;
}

/* Styling for the footer unordered list */
.footer-ul {
    list-style-type: none;
    display: flex;
    list-style: none;
    padding: 0;
}

/* Styling for list items in the footer unordered list */
.footer-ul li {
    margin-right: 1px;
}

/* Styling for the horizontal rule in the footer */
.footer-hr {
    border: none;
    background: #b5b5b5;
    height: 1px;
    margin: 20px 0;
}

/* Styling for the copyright text in the footer */
.Copyright {
    font-size: 12px;
    text-align: center;
    font-family: Trebuchet MS, sans-serif;
}
