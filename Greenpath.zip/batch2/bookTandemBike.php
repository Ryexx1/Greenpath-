<?php
function isBikeBooked($conn, $bike, $postDate)
{
    $stmt = $conn->prepare("SELECT COUNT(*) FROM booking WHERE bike = ? AND postDate = ?");
    $stmt->bind_param("ss", $bike, $postDate);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    return $count > 0;
}


$bikeAlreadyBooked = 0;
$success = 0;
$invalidPrefix = 0;
$notExists = 0; 
$fieldError= 0;
function startsWith($haystack, $prefixes) {
    foreach ($prefixes as $prefix) {
        $length = strlen($prefix);
        if ($length > 0 && substr($haystack, 0, $length) === $prefix) {
            return true;
        }
    }
    return false;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include('includes/dbh.inc.php');

    $randomPart = str_pad(mt_rand(0, 99999), 5, '0', STR_PAD_LEFT);
    $BookingNo = "8879" . $randomPart;

    $bikeType = "TDM";
    $bike = $_POST['bikeNumberInput'];
    $Studno= $_POST['studNo'];
    $postDate = $_POST['postDate'];
    $payment = $_POST['payment'];
    $allowedPrefixes = ["C20"];


    if (!startsWith($Studno, $allowedPrefixes)) {
      $invalidPrefix = 1;
        } else if (empty($bike) || empty($Studno) || empty($postDate) || empty($payment)) {
            $fieldError = 1;
        } else if (isBikeBooked($conn, $bike, $postDate)) {
          // The bike is already booked for the selected date
          $bikeAlreadyBooked = 1;
      }else {
            $stmt = $conn->prepare("INSERT INTO booking (BookingNo, bike, id_no, postDate, bikeType, payment) VALUES (?, ?, ?, ?, ?, ?)");

            if ($stmt === false) {
                die('Error in preparing the statement: ' . $conn->error);
            }

            $stmt->bind_param("ssssss", $BookingNo, $bike, $Studno, $postDate, $bikeType, $payment);

            if ($stmt->execute() === false) {
                die('Error in executing the statement: ' . $stmt->error);
            }

            $success = 1;

            $stmt->close();
        }
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mountain Bike Booking</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" media="screen" href="mtnBike.php">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <!-- Bootstrap Font Icon CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

        <!-- Include Pikaday CSS from CDN -->
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/pikaday/1.8.0/css/pikaday.min.css">
        <!-- Include Moment.js (required by Pikaday) from CDN -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>



</head>
<body>
    <!-- Navbar-->
    <div class="header">
    <div class="container1">
        <div class="logo-nav-container">
            <div class="navbar">
                <nav>  
                    <ul id="MenuItems" class="center-menu">
                        <li class="pages"><a href="guidelines.php" style="color: white">Guidelines</a></li>
                        <li class="pages"><a href="bookingCatalog.php" style="border-bottom: 2px solid white; color: white">Booking</a></li>
                        <li class="pages"><a href="repair.php" style="color: white">Maintenance</a></li>
                        <li class="logo-item"><a href="index.php"><img src="images/ima/1/r1.png" alt="Logo"></a></li> 
                        <li class="pages"><a href="transaction.php" style="color: white">Transaction</a></li>
                        <li class="pages"><a href="about.php" style="color: white">About Us</a></li>
                        <li class="pages"><a href="settings.php" style="color: white">Settings</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>
<!-- navbar endd -->


<div class="container">
<!-- C1 -->

<h2 style="color: black">Rent A Bike</h2>
<br>
<div class="row">
<div class="col-sm-7">

<!-- bike cards row 1 -->
<div class="row bikeContainer">
  <div class="col-xl-4 col-sm-6 col-12"> 
    <div class="card bike-card">
      <div class="card-content">
        <div class="card-body">
          <div class="media d-flex">
            <div class="align-self-center">
                <!-- <a href="https://www.flaticon.com/free-icons/leisure" title="leisure icons">Leisure icons created by Freepik - Flaticon</a> -->
                <img class="icons float-left" src="img/tandemBike.png" alt="Tandem Bike">
              
            </div>
            <div class="media-body text-right">
              <h4>07105</h4>
              <button class="pickBtn" data-bike-number="07105" >Pick</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-xl-4 col-sm-6 col-12">
    <div class="card bike-card">
      <div class="card-content">
        <div class="card-body">
          <div class="media d-flex">
            <div class="align-self-center">
                <!-- <a href="https://www.flaticon.com/free-icons/leisure" title="leisure icons">Leisure icons created by Freepik - Flaticon</a> -->
                <img class="icons float-left" src="img/tandemBike.png" alt="Tandem Bike">
            </div>
            <div class="media-body  text-right">
              <h4>07106</h4>
              <button class="pickBtn"data-bike-number="07106" >Pick</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-xl-4 col-sm-6 col-12">
    <div class="card bike-card">
      <div class="card-content">
        <div class="card-body">
          <div class="media d-flex">
            <div class="align-self-center">
                <!-- <a href="https://www.flaticon.com/free-icons/leisure" title="leisure icons">Leisure icons created by Freepik - Flaticon</a> -->
                <img class="icons float-left" src="img/tandemBike.png" alt="Tandem Bike">

            </div>
            <div class="media-body text-right">
              <h4>07107</h4>
              <button class="pickBtn" data-bike-number="07107" >Pick</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- bike cards row 1 END -->

<!-- bike cards row 2 -->
<div class="row bikeContainer">
  <div class="col-xl-4 col-sm-6 col-12"> 
    <div class="card bike-card">
      <div class="card-content">
        <div class="card-body">
          <div class="media d-flex">
            <div class="align-self-center">
                <!-- <a href="https://www.flaticon.com/free-icons/leisure" title="leisure icons">Leisure icons created by Freepik - Flaticon</a> -->
                <img class="icons float-left" src="img/tandemBike.png" alt="Tandem Bike">
            </div>
            <div class="media-body text-right">
              <h4>07108</h4>
              <button class="pickBtn" data-bike-number="07108" >Pick</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-xl-4 col-sm-6 col-12">
    <div class="card bike-card">
      <div class="card-content">
        <div class="card-body">
          <div class="media d-flex">
            <div class="align-self-center">
              <!-- <a href="https://www.flaticon.com/free-icons/leisure" title="leisure icons">Leisure icons created by Freepik - Flaticon</a> -->
              <img class="icons float-left" src="img/tandemBike.png" alt="Tandem Bike"> 
            </div>
            <div class="media-body text-right">
              <h4>07109</h4>
              <button class="pickBtn" data-bike-number="07109" >Pick</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-xl-4 col-sm-6 col-12">
    <div class="card bike-card">
      <div class="card-content">
        <div class="card-body">
          <div class="media d-flex">
            <div class="align-self-center">
                <!-- <a href="https://www.flaticon.com/free-icons/leisure" title="leisure icons">Leisure icons created by Freepik - Flaticon</a> -->
                <img class="icons float-left" src="img/tandemBike.png" alt="Tandem Bike">
            </div>
            <div class="media-body text-right">
              <h4>07110</h4>
              <button class="pickBtn" data-bike-number="07110" >Pick</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- bike cards row 2 END -->
<!-- bike cards row 3 -->
<div class="row bikeContainer">
  <div class="col-xl-4 col-sm-6 col-12"> 
    <div class="card bike-card">
      <div class="card-content">
        <div class="card-body">
          <div class="media d-flex">
            <div class="align-self-center">
                <!-- <a href="https://www.flaticon.com/free-icons/leisure" title="leisure icons">Leisure icons created by Freepik - Flaticon</a> -->
                <img class="icons float-left" src="img/tandemBike.png" alt="Tandem Bike">
            </div>
            <div class="media-body text-right">
              <h4>07111</h4>
              <button class="pickBtn" data-bike-number="07108" >Pick</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-xl-4 col-sm-6 col-12">
    <div class="card bike-card">
      <div class="card-content">
        <div class="card-body">
          <div class="media d-flex">
            <div class="align-self-center">
              <!-- <a href="https://www.flaticon.com/free-icons/leisure" title="leisure icons">Leisure icons created by Freepik - Flaticon</a> -->
              <img class="icons float-left" src="img/tandemBike.png" alt="Tandem Bike"> 
            </div>
            <div class="media-body text-right">
              <h4>07112</h4>
              <button class="pickBtn" data-bike-number="07109" >Pick</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-xl-4 col-sm-6 col-12">
    <div class="card bike-card">
      <div class="card-content">
        <div class="card-body">
          <div class="media d-flex">
            <div class="align-self-center">
                <!-- <a href="https://www.flaticon.com/free-icons/leisure" title="leisure icons">Leisure icons created by Freepik - Flaticon</a> -->
                <img class="icons float-left" src="img/tandemBike.png" alt="Tandem Bike">
            </div>
            <div class="media-body text-right">
              <h4>07113</h4>
              <button class="pickBtn" data-bike-number="07110" >Pick</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- bike cards row 3 END -->
</div>
<!-- bike cards column end -->

  <!-- cards end here -->
    <!-- C1 end  -->


    <!-- C2 --> <div class="col-sm-5  col-12">
        <div class="form"> 
            <!-- Repair request Form -->
            <form action=" " method="POST" >

                <br>

                <div class="single-row">       
                    <!--readonly input for the user's selected bike number  -->
                    <input type="text" id="bikeNumberInput" name="bikeNumberInput" value="" placeholder="Pick a Bike to Record" readonly/>
                    <!-- Input field for Student Number, required -->
                    <div class="single-column" id="column1">
                        <input type="text" id="studNum"name="studNo" placeholder="Student Number" required>
                        <div class="invalid-feedback">Please fill out this field.</div>
                    </div>
                    <!-- Input field for Date, required -->
                    <div class="single-column" id="column1">
                        <input type="text" id="postDate" name="postDate" class="datepicker" placeholder="Pick a Date" required readonly>
                        <div class="invalid-feedback">Please fill out this field.</div>
                    </div>

                      <!-- Dropdown for Payment Option, required -->
                      <div class="single-column">
                          <button type="button" name="payment" class="btn dropdown-toggle" id="PaymentDropDown" onclick="dropdownSelect()" data-toggle="dropdown" data-toggle="tooltip" data-placement="top" title="Choose when to pay your booking charges" aria-haspopup="true" aria-expanded="false" data-validation="required">
                              Payment Option
                          </button>
                          <input type="hidden" name="payment" id="PaymentInputValue" required readonly>
                          <div class="dropdown-menu">
                              <div class="dropdown-item" onclick="updatePlaceValue('Before Booking', 'PaymentInputValue')">Pay Before Booking</div>
                              <div class="dropdown-item" onclick="updatePlaceValue('After Booking', 'PaymentInputValue')">Pay After Booking</div>
                          </div> <!-- dropdown menu div -->
                      </div>

                </div>
                
            
                <!-- Submit button -->
                <input type="submit" value="SUBMIT" id="btn" class="submitBtn"  onclick="onSubmitButtonClick()"  />
                <br><br>
                <span id="error-msg" style="color: red;"></span>
            </form>
        </div> 
    </div>
</div> 
</div><!-- form column end -->
<!-- C2 end -->

</div> <!-- form and bike row end -->


<!-- C3 -->
<!-- Modal for booking ticket -->
<div class="modal fade custom-modal" id="bookingDetailsModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <div class="row">
          <!-- Column for "Payment" and "Student Number" -->
          <div class="col-8">
            <p class="idNum"><?= $Studno ?></p>
            <p class="pay"><?= $payment ?></p>
          </div>
          
          <!-- Column for "Booking number," "Date," and "Bike Number" -->
          <div class="col-4 ticketDetails">
            
            <p class="bookno"><?= $BookingNo ?></p>
            <p class="bikeno"><?=$bikeType?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?= $bike?></p>  
            
            <p class="bookDate"><?= $postDate ?> 2023</p>
              <!-- notes -->
            <div class="float-center sideNote">
              <p class="blinking-text">Take a Screenshot of Your Ticket <br> Make sure to return the bike before your Booking period ends</p>
              
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>




<!-- modal end -->
<?php
if($success){
      echo "<script>
          $(document).ready(function () {
            $('#bookingDetailsModal').modal('show');
          });
          </script>";
}
if($fieldError){
  echo "<script> document.getElementById('error-msg').innerHTML = 'Fill out all required inputs'; </script>";
}
if($invalidPrefix){
  echo "<script> document.getElementById('error-msg').innerHTML = 'Invalid Student Number Format'; </script>";
}
if($bikeAlreadyBooked){
  echo "<script>
          document.getElementById('error-msg').innerHTML = 'This bike is already booked. Pick a different date';
        </script>";
}
?>




<!--- Footer Section -->
<div class="footer">
    <div class="footer-container">
        <div class="footer-row">

        <!-- Column 1 -->
        <div class="footer-col-1">
            <h3 class="footer-h3">Follow Us</h3>
            <ul class="footer-ul">
                <a href="https://www.facebook.com/profile.php?id=61552094544554&mibextid=ZbWKwL">
                    <li>
                        <img class="social-icon" src="images/ima/1/facebook.png" alt="Facebook">
                    </li>
                </a>
                <a href="https://instagram.com/greenpath_rental?igshid=MzMyNGUyNmU2YQ==">
                    <li>
                        <img class="social-icon" src="images/ima/1/insta.png" alt="Instagram">
                    </li>
                </a>
            </ul>
        </div>

        <!-- Column 2 -->
        <div class="footer-col-2">
            <img src="images/ima/1/r1.png">
            <p class="footer-p">Paving Paths for Brighter Futures</p>
        </div>

        <!-- Column 3 -->
        <div class="footer-col-3">
            <h3 class="footer-h3">Contact Us</h3>
            <p class="footer-p" style="font-weight: lighter;">greenpath@gmail.com</p><br>
            <p class="footer-p" style="font-weight: lighter;">(+63) 968-459-3721</p>
        </div>
        </div>
        <hr class="footer-hr">
        <p class="Copyright" style="font-weight: bold;">Copyright 2022</p>
    </div>
</div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>
<!-- Bootstrap Datepicker JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<!-- Include Pikaday JavaScript from CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/pikaday/1.8.0/pikaday.min.js"></script>
<!-- Include Moment.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>

<!-- Include DatePair CSS and JavaScript -->
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap-daterangepicker@3.0.5/daterangepicker.css" />
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/bootstrap-daterangepicker@3.0.5/daterangepicker.js"></script>

<script src="js/bookMtn.js"></script>
</body>
</html>