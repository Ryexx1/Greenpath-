<?php
$invalid = 0; 
$success = 0; 
$notExist = 0;
include('includes/dbh.inc.php');

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the submitted ID number and password
    $id = $_POST['idNumber'];
    $password = $_POST['password'];

    // Perform a query to get the hashed password for the given ID number
    $sql = "SELECT * FROM account WHERE id_no = '$id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $hashedPassword = $row['pass'];

        // Check if the provided password matches the hashed password
        if (password_verify($password, $hashedPassword)) {
            // Password is correct
           $success = 1; 
         
        } else {
            // Password is incorrect, show an error message
           $invalid =1; 
        }
    } else {
        // Account does not exist, show an error message
        $notExist=1; 
    }
}
// Handle AJAX request for canceling booking
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'cancelBooking') {
    $bookingID = $_POST['BookingNo'];
   
    $sql = "DELETE FROM booking WHERE BookingNo = $bookingID";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        echo json_encode(['status' => 'success', 'message' => 'Booking canceled successfully.']);
      
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to cancel booking.']);
    }

    exit;
}

// Handle AJAX request for canceling repair
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'cancelRepair') {
    $maintenanceID = $_POST['BookingNo'];
    
    $sql = "DELETE FROM maintenance WHERE BookingNo = $maintenanceID";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        echo json_encode(['status' => 'success', 'message' => 'Repair canceled successfully.']);
       
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to cancel repair.']);
    }

    exit;
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction</title>
    
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">   
    <link rel="stylesheet" type="text/css" media="screen" href="history.php">
    <link rel="preconnect" href="https://fonts.gstatic.com">
   
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
   
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
     <!-- jQuery first, then Popper.js, then Bootstrap JS -->
   
     <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</head>
<body>
       <!-- Navbar-->
       <div class="header">
    <div class="container1">
        <div class="logo-nav-container">
            <div class="navbar">
                <nav>  
                    <ul id="MenuItems" class="center-menu">
                        <li class="pages"><a href="guidelines.php" style="color: white">Guidelines</a></li>
                        <li class="pages"><a href="bookingCatalog.php" style="color: white">Booking</a></li>
                        <li class="pages"><a href="repair.php" style="color: white">Maintenance</a></li>
                        <li class="logo-item"><a href="index.php"><img src="images/ima/1/r1.png" alt="Logo"></a></li> 
                        <li class="pages"><a href="transaction.php" style="border-bottom: 2px solid white; color: white">Transaction</a></li>
                        <li class="pages"><a href="about.php" style="color: white">About Us</a></li>
                        <li class="pages"><a href="settings.php" style="color: white">Settings</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>
<!-- navbar endd -->


<div class="container">

<!-- Modal -->
<div class="modal" id="credentialsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Enter Your Credentials</h5>
              
            </div>
            <div class="modal-body">
                <h6 id="msg">Fill out to access and edit your transaction history</h6>
               
                <div class="form">
                    <form id="credentialsForm" action="" method="POST">
                        <div class="mb-3">
                            <input type="text" class="form-control" id="idNumber" name="idNumber" placeholder="ID Number" required>
                        </div>
                        <div class="mb-3">
                            <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                        </div>
                        <span id="error-msg" style="color: red; font-size: 15px;"></span>
                        <button type="submit"id="btn"class="btn submit-btn">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- modal end -->

<!-- C1 -->
<?php
    if($success){
           // If login is successful, hide the modal, make backdrop not static, and show a success message
            echo '<script>
            $(document).ready(function () {
                $("#credentialsModal").modal("hide");
                $("#credentialsForm").remove();

                $("#credentialsModal").data("bs.modal")._config.backdrop = true;
                $("#credentialsModal").data("bs.modal")._config.keyboard = true;
                
                document.getElementById("msg").innerHTML = "Success, you can now access your history";
                document.getElementById("msg").style.color = "green";
                
            });
        </script>';

        $sqlBooking = "SELECT * FROM booking WHERE id_no = '$id'";
        $resultBooking = $conn->query($sqlBooking);
        
        $sqlMaintenance = "SELECT * FROM maintenance WHERE id_no = '$id'";
        $resultMaintenance = $conn->query($sqlMaintenance);
        
        // Check if both result sets are empty
        if ($resultBooking->num_rows === 0 && $resultMaintenance->num_rows === 0) {
            echo "<div class='container mt-4 noData'>";
            echo "<img src='img/files.png' style='text-align: center; width: 150px;'>";
            echo "<h2>No Data Available</h2>";
            echo "</div>";
        } else {
            $combinedData = array();
        
            while ($rowBooking = $resultBooking->fetch_assoc()) {
                $combinedData[] = array(
                    'type' => 'booking',
                    'date' => $rowBooking['postDate'],
                    'data' => $rowBooking
                );
            }
        
            while ($rowMaintenance = $resultMaintenance->fetch_assoc()) {
                $combinedData[] = array(
                    'type' => 'maintenance',
                    'date' => $rowMaintenance['BookingNo'], // Use bookingNo for maintenance to maintain chronological order
                    'data' => $rowMaintenance
                );
            }
        
            // Sort the combined data by date
            usort($combinedData, function ($a, $b) {
                return strtotime($a['date']) - strtotime($b['date']);
            });
        
            // Display the combined and sorted data in Bootstrap cards with three columns per row
            echo "<div class='container mt-4'>";
            echo "<h2 id='historyHeading'>Transaction History</h2>";
        
            // Counter for columns
            $columnCount = 0;
        
            foreach ($combinedData as $entry) {
                // Start a new row for every three columns
                if ($columnCount % 3 === 0) {
                    echo'<br>';
                    echo "<div class='row'>";
                }
        
                echo "<div class='col-4 col-sm-4 col-xl-4' >";
                echo "<div class='card'>";
                echo "<div class='card-header'>" . ucfirst($entry['type']) . " - " . $entry['date'] . "</div>";
                echo "<div class='card-body'>";
        
               // Output details based on the entry type
                if ($entry['type'] == 'booking') {
                    echo "<p class='card-text'>Bike: " . $entry['data']['bike'] . "</p>";
                    echo "<p class='card-text'>Type: " . $entry['data']['bikeType'] . "</p>";
                    echo "<p class='card-text'>Payment: " . $entry['data']['payment'] . "</p>";
                    echo "<form class='cancel-form' action='' method='POST'>";
                    echo "<input type='hidden' name='action' value='cancelBooking'>";
                    echo "<input type='hidden' name='BookingNo' value='" . $entry['data']['BookingNo'] . "'>";
                    echo "<button type='submit' class='btn cancel' onClick='cancelBook()'>Cancel</button>";
                    echo "</form>";
                    
                } else {
                    echo "<p class='card-text'>Place: " . $entry['data']['place'] . "</p>";
                    echo "<p class='card-text'>Type: " . $entry['data']['repairType'] . "</p>";
                    echo "<p class='card-text'>Comment: " . $entry['data']['comment'] . "</p>";
                    echo "<form class='cancel-form' action='' method='POST'>";
                    echo "<input type='hidden' name='action' value='cancelRepair'>";
                    echo "<input type='hidden' name='BookingNo' value='" . $entry['data']['BookingNo'] . "'>";
                    echo "<button type='submit' class='btn cancel' onClick='cancelRepair()'>Cancel</button>";
                    echo "</form>";
                }

                echo "</div></div>";
                echo "</div>";
        
                // End the row for every three columns
                if ($columnCount % 3 === 2 || $columnCount === count($combinedData) - 1) {
                    echo "</div>"; // Close the row
                }
        
                // Increment the column count
                $columnCount++;
               
            }
        
            echo "</div>"; // Close the container
        }
        

}
// success end 

    if($invalid){
        echo'<script> document.getElementById("error-msg").innerHTML = "Incorrect Password"</script>';   
    }
    if($notExist){
        echo'<script> document.getElementById("error-msg").innerHTML = "Invalid Credentials"</script>';   

    }
?>

</div>
<!--- Footer Section -->
<div class="footer">
    <div class="footer-container">
        <div class="footer-row">

        <!-- Column 1 -->
        <div class="footer-col-1">
            <h3 class="footer-h3">Follow Us</h3>
            <ul class="footer-ul">
                <a href="https://www.facebook.com/profile.php?id=61552094544554&mibextid=ZbWKwL">
                    <li>
                        <img class="social-icon" src="images/ima/1/facebook.png" alt="Facebook">
                    </li>
                </a>
                <a href="https://instagram.com/greenpath_rental?igshid=MzMyNGUyNmU2YQ==">
                    <li>
                        <img class="social-icon" src="images/ima/1/insta.png" alt="Instagram">
                    </li>
                </a>
            </ul>
        </div>

        <!-- Column 2 -->
        <div class="footer-col-2">
            <img src="images/ima/1/r1.png">
            <p class="footer-p">Paving Paths for Brighter Futures</p>
        </div>

        <!-- Column 3 -->
        <div class="footer-col-3">
            <h3 class="footer-h3">Contact Us</h3>
            <p class="footer-p" style="font-weight: lighter;">greenpath@gmail.com</p><br>
            <p class="footer-p" style="font-weight: lighter;">(+63) 968-459-3721</p>
        </div>
        </div>
        <hr class="footer-hr">
        <p class="Copyright" style="font-weight: bold;">Copyright 2022</p>
    </div>
</div>
<script src="js/trans.js"></script>

</body>
</html>
